<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_GenericGateway2 extends MultiSafepay_Msp_Model_Gateway_GenericBase
{
    protected $_code = 'msp_generic_gateway2';
    protected $_isRegularGateway = true;
    public $_model = 'genericGateway2';
}
