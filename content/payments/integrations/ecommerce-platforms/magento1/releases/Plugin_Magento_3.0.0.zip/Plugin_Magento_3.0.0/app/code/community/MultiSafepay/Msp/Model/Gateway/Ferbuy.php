<?php

class MultiSafepay_Msp_Model_Gateway_Ferbuy extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_ferbuy";
    public $_model = "ferbuy";
    public $_gateway = "FERBUY";

}
