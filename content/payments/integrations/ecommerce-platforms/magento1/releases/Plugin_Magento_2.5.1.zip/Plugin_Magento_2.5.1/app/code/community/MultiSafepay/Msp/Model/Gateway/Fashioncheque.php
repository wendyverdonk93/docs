<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Fashioncheque extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_fashioncheque";
    public $_model = "fashioncheque";
    public $_gateway = "FASHIONCHEQUE";

}
