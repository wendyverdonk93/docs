<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Setup extends Mage_Catalog_Model_Resource_Setup
{
    
}
