<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Fashiongiftcard extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_fashiongiftcard";
    public $_model = "fashiongiftcard";
    public $_gateway = "FASHIONGIFTCARD";

}
