<?php

$_['heading_title'] = 'MultiSafepay Babygiftcard';

// Text
$_['text_multisafepay_babygiftcard'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/babygiftcard.svg" alt="MultiSafepay Babygiftcard" title="MultiSafepay Babygiftcard"/></a>';
?>