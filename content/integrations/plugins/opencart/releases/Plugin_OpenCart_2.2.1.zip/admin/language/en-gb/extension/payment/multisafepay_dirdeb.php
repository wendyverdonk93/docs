<?php

$_['heading_title'] = 'MultiSafepay DirectDebit';

// Text
$_['text_multisafepay_dirdeb'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/dirdeb.svg" alt="MultiSafepay DirectDebit" title="MultiSafepay DirectDebit"/></a>';

?>