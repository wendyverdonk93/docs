<?php

$_['heading_title'] = 'MultiSafepay Maestro';

// Text
$_['text_multisafepay_maestro'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/maestro.svg" alt="MultiSafepay Maestro" title="MultiSafepay Maestro"/></a>';
?>