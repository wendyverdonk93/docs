<?php

$_['heading_title'] = 'MultiSafepay Trustly';

// Text
$_['text_multisafepay_trustly'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/trustly.svg" alt="MultiSafepay Trustly" title="MultiSafepay Trustly"/></a>';
?>