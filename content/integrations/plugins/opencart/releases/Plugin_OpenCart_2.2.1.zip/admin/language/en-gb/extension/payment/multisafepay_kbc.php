<?php

$_['heading_title'] = 'MultiSafepay KBC';

// Text
$_['text_multisafepay_kbc'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/kbc.svg" alt="MultiSafepay KBC" title="MultiSafepay KBC"/></a>';

?>