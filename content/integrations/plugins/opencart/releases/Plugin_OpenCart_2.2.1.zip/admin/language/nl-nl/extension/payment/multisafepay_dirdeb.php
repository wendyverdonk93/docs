<?php

$_['heading_title'] = 'MultiSafepay Incasso';

// Text
$_['text_multisafepay_dirdeb'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/dirdeb.svg" alt="MultiSafepay Incasso" title="MultiSafepay Incasso"/></a>';

?>