<?php

$_['heading_title'] = 'MultiSafepay GiroPay';

// Text
$_['text_multisafepay_giropay'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/giropay.svg" alt="MultiSafepay GiroPay" title="MultiSafepay GiroPay"/></a>';

?>