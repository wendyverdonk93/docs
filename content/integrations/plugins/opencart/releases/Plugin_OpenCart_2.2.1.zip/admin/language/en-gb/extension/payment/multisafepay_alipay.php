<?php

$_['heading_title'] = 'MultiSafepay Alipay';

// Text
$_['text_multisafepay_alipay'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/alipay.svg" alt="MultiSafepay Alipay" title="MultiSafepay Alipay"/></a>';

?>