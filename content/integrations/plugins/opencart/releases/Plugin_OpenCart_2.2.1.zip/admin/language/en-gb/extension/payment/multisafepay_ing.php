<?php

$_['heading_title'] = 'MultiSafepay ING Home\'Pay';

// Text
$_['text_multisafepay_ing'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/ing.svg" alt="MultiSafepay ING Home\'Pay" title="MultiSafepay ING Home\'Pay"/></a>';
?>