<?php

$_['heading_title'] = 'MultiSafepay Pay After Delivery';

// Text
$_['text_multisafepay_payafter'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/payafter.svg" alt="MultiSafepay Pay After Delivery" title="MultiSafepay Pay After Delivery"/></a>';
?>