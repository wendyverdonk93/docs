<?php

$_['heading_title'] = 'MultiSafepay Webshop giftcard';

// Text
$_['text_multisafepay_webshopgiftcard'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/webshopgiftcard.svg" alt="MultiSafepay Webshop giftcard" title="MultiSafepay Webshop giftcard"/></a>';
?>