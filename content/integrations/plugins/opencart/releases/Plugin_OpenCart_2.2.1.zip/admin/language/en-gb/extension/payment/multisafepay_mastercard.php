<?php

$_['heading_title'] = 'MultiSafepay MasterCard';

// Text
$_['text_multisafepay_mastercard'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/mastercard.svg" alt="MultiSafepay MasterCard" title="MultiSafepay MasterCard"/></a>';
?>