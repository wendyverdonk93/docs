<?php

$_['heading_title'] = 'MultiSafepay iDEAL';

// Text
$_['text_multisafepay_ideal'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/ideal.svg" alt="MultiSafepay iDEAL" title="MultiSafepay iDEAL"/></a>';
?>