<?php

$_['heading_title'] = 'MultiSafepay Bancontact';

// Text
$_['text_multisafepay_mistercash'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/mistercash.svg" alt="MultiSafepay Bancontact" title="MultiSafepay Bancontact"/></a>';
?>