<?php

$_['heading_title'] = 'MultiSafepay VVV-Cadeaukaart';

// Text
$_['text_multisafepay_vvv'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/vvv.svg" alt="MultiSafepay VVV-Cadeaukaart" title="MultiSafepay VVV-Cadeaukaart"/></a>';
?>