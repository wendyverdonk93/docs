<?php

$_['heading_title'] = 'MultiSafepay Boekenbon';

// Text
$_['text_multisafepay_boekenbon'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/boekenbon.svg" alt="MultiSafepay Boekenbon" title="MultiSafepay Boekenbon"/></a>';

?>