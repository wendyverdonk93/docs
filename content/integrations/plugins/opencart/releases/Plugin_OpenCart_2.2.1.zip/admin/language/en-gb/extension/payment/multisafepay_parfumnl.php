<?php

$_['heading_title'] = 'MultiSafepay ParfumNL';

// Text
$_['text_multisafepay_parfumnl'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="view/image/payment/multisafepay.svg" alt="MultiSafepay" title="MultiSafepay" style="border: 1px solid #EEEEEE;" /></a>';
?>