<?php

$_['heading_title'] = 'MultiSafepay Lief';

// Text
$_['text_multisafepay_lief'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/lief.svg" alt="MultiSafepay Lief" title="MultiSafepay Lief"/></a>';
?>