<?php

$_['heading_title'] = 'MultiSafepay Gezondheidsbon';

// Text
$_['text_multisafepay_gezondheidsbon'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/gezondheidsbon.svg" alt="MultiSafepay Gezondheidsbon" title="MultiSafepay Gezondheidsbon"/></a>';

?>