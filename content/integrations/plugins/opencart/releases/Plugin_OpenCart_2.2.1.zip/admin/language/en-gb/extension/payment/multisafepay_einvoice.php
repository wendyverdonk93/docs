<?php

$_['heading_title'] = 'MultiSafepay E-Invoice';

// Text
$_['text_multisafepay_einvoice'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/einvoice.svg" alt="MultiSafepay E-Invoice" title="MultiSafepay E-Invoice"/></a>';
?>