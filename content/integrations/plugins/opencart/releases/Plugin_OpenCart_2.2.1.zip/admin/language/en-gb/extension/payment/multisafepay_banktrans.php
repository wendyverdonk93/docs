<?php

$_['heading_title'] = 'MultiSafepay bank transfer';

// Text
$_['text_multisafepay_banktrans'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/banktrans.svg" alt="MultiSafepay Banktransfer" title="MultiSafepay Banktransfer"/></a>';

?>