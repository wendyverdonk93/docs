<?php

$_['heading_title'] = 'MultiSafepay paysafecard';

// Text
$_['text_multisafepay_paysafecard'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/paysafecard.svg" alt="MultiSafepay paysafecard" title="MultiSafepay paysafecard"/></a>';
?>