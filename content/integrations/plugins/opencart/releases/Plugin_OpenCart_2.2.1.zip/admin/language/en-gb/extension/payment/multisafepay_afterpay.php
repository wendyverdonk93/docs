<?php

$_['heading_title'] = 'MultiSafepay Afterpay';
$_['text_multisafepay_afterpay'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/afterpay.svg" alt="MultiSafepay Afterpay" title="MultiSafepay Afterpay"/></a>';
?>