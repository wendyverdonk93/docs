<?php

$_['heading_title'] = 'MultiSafepay Dotpay';

// Text
$_['text_multisafepay_dotpay'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/dotpay.svg" alt="MultiSafepay Dotpay" title="MultiSafepay Dotpay"/></a>';
?>