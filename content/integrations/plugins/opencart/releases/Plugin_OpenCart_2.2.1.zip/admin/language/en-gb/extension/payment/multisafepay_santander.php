<?php

$_['heading_title'] = 'MultiSafepay Santander Betaalplan';

// Text
$_['text_multisafepay_santander'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/santander.svg" alt="MultiSafepay Santander Betaalplan" title="MultiSafepay Santander Betaalplan"/></a>';
?>