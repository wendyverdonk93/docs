<?php

$_['heading_title'] = 'MultiSafepay Fashioncheque';

// Text
$_['text_multisafepay_fashioncheque'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/fashioncheque.svg" alt="MultiSafepay Fashioncheque" title="MultiSafepay Fashioncheque"/></a>';

?>