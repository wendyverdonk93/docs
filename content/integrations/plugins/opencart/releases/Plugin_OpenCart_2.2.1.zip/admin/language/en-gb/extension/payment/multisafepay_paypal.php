<?php

$_['heading_title'] = 'MultiSafepay PayPal';

// Text
$_['text_multisafepay_paypal'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/paypal.svg" alt="MultiSafepay PayPal" title="MultiSafepay PayPal"/></a>';
?>