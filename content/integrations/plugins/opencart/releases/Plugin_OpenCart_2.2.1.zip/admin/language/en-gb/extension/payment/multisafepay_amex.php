<?php

$_['heading_title'] = 'MultiSafepay AMEX';

// Text
$_['text_multisafepay_amex'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/amex.svg" alt="MultiSafepay Amex" title="MultiSafepay Amex"/></a>';
?>