<?php

$_['heading_title'] = 'MultiSafepay Belfius';

// Text
$_['text_multisafepay_belfius'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/belfius.svg" alt="MultiSafepay Belfius" title="MultiSafepay Belfius"/></a>';
?>