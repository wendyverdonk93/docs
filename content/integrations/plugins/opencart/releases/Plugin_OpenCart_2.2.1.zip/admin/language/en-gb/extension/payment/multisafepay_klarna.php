<?php

$_['heading_title'] = 'MultiSafepay Klarna';

// Text
$_['text_multisafepay_klarna'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/klarna.svg" alt="MultiSafepay Klarna" title="MultiSafepay Klarna"/></a>';
?>