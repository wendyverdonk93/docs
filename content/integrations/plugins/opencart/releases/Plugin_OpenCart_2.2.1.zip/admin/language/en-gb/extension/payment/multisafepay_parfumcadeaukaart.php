<?php

$_['heading_title'] = 'MultiSafepay Parfumcadeaukaart';

// Text
$_['text_multisafepay_parfumcadeaukaart'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/parfumcadeaukaart.svg" alt="MultiSafepay Parfumcadeaukaart" title="MultiSafepay Parfumcadeaukaart"/></a>';

?>