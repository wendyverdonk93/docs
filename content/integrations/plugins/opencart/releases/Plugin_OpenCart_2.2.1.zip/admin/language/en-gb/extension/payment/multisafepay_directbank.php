<?php

$_['heading_title'] = 'MultiSafepay SOFORT Banking';

// Text
$_['text_multisafepay_directbank'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/directbank.svg" alt="MultiSafepay SOFORT Banking" title="MultiSafepay SOFORT Banking"/></a>';
?>