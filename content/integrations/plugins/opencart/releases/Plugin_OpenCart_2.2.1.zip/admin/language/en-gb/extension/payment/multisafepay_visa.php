<?php

$_['heading_title'] = 'MultiSafepay VISA';

// Text
$_['text_multisafepay_visa'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img height=40 width=auto src="../image/multisafepay/visa.svg" alt="MultiSafepay VISA" title="MultiSafepay VISA"/></a>';
?>