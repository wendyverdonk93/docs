<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Visa extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_visa";
    public $_model = "visa";
    public $_gateway = "VISA";

    public $_formBlockType = 'msp/tokenization';

    public function assignData($data)
    {
        parent::assignData($data);
        $session = Mage::getSingleton('checkout/session');
        $session->setData('payment_additional', $data);
        return $this;
    }
}
