<?php

/**
 *
 * @category MultiSafepay
 * @package  MultiSafepay_Msp
 */
class MultiSafepay_Msp_Model_Gateway_Degrotespeelgoedwinkel extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_degrotespeelgoedwinkel";
    public $_model = "degrotespeelgoedwinkel";
    public $_gateway = "DEGROTESPEELGOEDWINKEL";

}
