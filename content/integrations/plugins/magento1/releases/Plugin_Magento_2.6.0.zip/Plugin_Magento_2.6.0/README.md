<p align="center">
  <img src="https://www.multisafepay.com/img/multisafepaylogo.svg" width="400px" position="center">
</p>

# MultiSafepay plugin for Magento 1

Easily integrate MultiSafepay payment solutions into your Magento 1 webshop with the free and completely new MultiSafepay Magento 1 plugin.

## About MultiSafepay ##
MultiSafepay is a collecting payment service provider which means we take care of the agreements, technical details and payment collection required for each payment method. You can start selling online today and manage all your transactions from one place.
## Supported Payment Methods ##
The supported Payment Methods & Giftcards for this plugin can be found over here: [Payment Methods & Giftcards](https://docs.multisafepay.com/plugins/magento1/faq/#available-payment-methods-in-magento-1)

## Requirements
- To use the plugin you need a MultiSafepay account. You can create a test account on https://testmerchant.multisafepay.com/signup
- Magento 1.x

## Installation through SFTP
1. Unpack the content of the .ZIP file in the root of your webshop
2. Login in your backend and navigate to System->Configuration->Cache. Clear your invalid cache.

For additional information or instructions please see our [installation & configuration manual](https://docs.multisafepay.com/plugins/magento1/manual/)

## Support
You can create issues on our repository. If you need any additional help or support, please contact <a href="mailto:integration@multisafepay.com">integration@multisafepay.com</a>
