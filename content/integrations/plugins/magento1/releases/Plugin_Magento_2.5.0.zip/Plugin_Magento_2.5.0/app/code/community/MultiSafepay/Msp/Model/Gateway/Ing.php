<?php

class MultiSafepay_Msp_Model_Gateway_Ing extends MultiSafepay_Msp_Model_Gateway_Abstract
{

    protected $_code = "msp_ing";
    public $_model = "ing";
    public $_gateway = "INGHOME";

}
