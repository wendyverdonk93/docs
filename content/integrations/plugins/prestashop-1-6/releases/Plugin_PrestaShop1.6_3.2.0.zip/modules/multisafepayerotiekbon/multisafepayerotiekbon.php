<?php
/**
 *  MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@MultiSafepay.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

require_once (_PS_MODULE_DIR_.'multisafepay/api/Autoloader.php');
require_once (_PS_MODULE_DIR_.'multisafepay/helpers/Autoloader.php');

if (!defined('_PS_VERSION_')) {
    exit;
}

class Multisafepayerotiekbon extends PaymentModule
{
    public function __construct()
    {
        $this->name                     = 'multisafepayerotiekbon';
        $this->tab                      = 'payments_gateways';
        $this->version                  = '3.2.0';
        $this->author                   = 'MultiSafepay';

        $this->need_instance            = 1;
        $this->ps_versions_compliancy   = array('min' => '1.6', 'max' => '1.6');
//      $this->dependencies             = array('multisafepay');

        $this->currencies               = true;
        $this->currencies_mode          = 'checkbox';

        $this->module_key               = '54635c1e3a467c329ab7494101b6bfc4';
        $this->bootstrap                = true;
        parent::__construct();
        
        $this->gateway                  = 'EROTIEKBON';
        $this->displayName              = $this->l('Erotiekbon');
        $this->description              = $this->l('This module allows you to accept payments by MultiSafepay.');
        $this->confirmUninstall         = $this->l('Are you sure you want to delete these details?');
    }

    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('backOfficeHeader') ||
            !$this->registerHook('payment')) {
            return false;
        }
        Configuration::updateValue('MULTISAFEPAY_EROTIEKBON_API_KEY', '');
        Configuration::updateValue('MULTISAFEPAY_EROTIEKBON_SANDBOX', '');
        return true;
    }

    public function uninstall()
    {
        Configuration::deleteByName('MULTISAFEPAY_EROTIEKBON_API_KEY');
        Configuration::deleteByName('MULTISAFEPAY_EROTIEKBON_SANDBOX');
        return parent::uninstall();
    }

    public function hookPayment()
    {
        if (!$this->active) {
            return;
        }

        $this->context->smarty->clearAssign(array('direct', 'birthday', 'gender', 'phone', 'bankaccount', 'issuers', 'fee' ));

        $this->context->smarty->assign(array(
            'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/' . $this->name . '/',
            'main_path_ssl' => _PS_ROOT_DIR_,
            'moduleLink'    => $this->name,
            'gateway'       => $this->gateway,
            'name'          => $this->displayName,
        ));
        return $this->display(__FILE__, 'payment.tpl');
    }

    public function hookBackOfficeHeader()
    {
        $this->context->controller->addCSS($this->_path.'views/css/multisafepay.css', 'all');
        $this->context->smarty->assign(array( 'Multisafepay_module_dir' => _MODULE_DIR_.$this->name ));
    }

    public function getContent()
    {
        if (Tools::isSubmit('submit'.$this->name)) {
            Configuration::updateValue('MULTISAFEPAY_EROTIEKBON_API_KEY', Tools::getValue('MULTISAFEPAY_EROTIEKBON_API_KEY'));
            Configuration::updateValue('MULTISAFEPAY_EROTIEKBON_SANDBOX', Tools::getValue('MULTISAFEPAY_EROTIEKBON_SANDBOX'));
        }

        $CheckConnection = new CheckConnection('', '');
        $check = $CheckConnection->checkConnection( Tools::getValue('MULTISAFEPAY_EROTIEKBON_API_KEY'),
                                                    Tools::getValue('MULTISAFEPAY_EROTIEKBON_SANDBOX'));

        if ($check) {
            $output = $this->displayError($check);
        }else{
            $output = $this->displayConfirmation($this->l('Settings updated'));
        }
        
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module          = $this;
        $helper->name_controller = $this->name;
        $helper->token           = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex    = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $helper->default_form_language    = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title          = $this->displayName;
        $helper->show_toolbar   = true; // false -> remove toolbar
        $helper->toolbar_scroll = true; // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action  = 'submit'.$this->name;
        $helper->toolbar_btn = array(
            'save' => array(
                'desc' => $this->l('Save') ,
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
            ) ,
            'back' => array(
                'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules') ,
                'desc' => $this->l('Back to list')
            )
        );
        $fields_form = array();
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Account settings') ,
                'image' => '../img/admin/edit.gif'
            ) ,
            'input' => array(
                array(
                    'type'          =>  'text',
                    'label'         =>  $this->l('API Key'),
                    'name'          =>  'MULTISAFEPAY_EROTIEKBON_API_KEY',
                    'size'          =>  20,
                    'required'      =>  false,
                    'hint'          =>  $this->l('The API-Key from the corresponding website in your MultiSafepay account. Leave empty to use the API-Key configured in the default MultiSafepay gateway'),
                ),
             array(
                    'type'          =>  'switch',
                    'label'         =>  $this->l('Test account'),
                    'name'          =>  'MULTISAFEPAY_EROTIEKBON_SANDBOX',
                    'class'         =>  't',
                    'is_bool'       =>  true,
                    'required'      =>  false,
                    'hint'          =>  $this->l('Use Live-account the API-Key is from your MultiSafepay LIVE-account.<br/>Use Test -account if the API-Key is from your MultiSafepay TEST-account.'),
                    'values'        =>  array(
                                            array(
                                                'id'    => 'test',
                                                'value' => true,
                                                'label' => $this->l('Test account')
                                            ),
                                            array(
                                                'id'    => 'prod',
                                                'value' => false,
                                                'label' => $this->l('Live account')
                                            )
                                        )
                ),
            ) ,
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper->fields_value['MULTISAFEPAY_EROTIEKBON_API_KEY']    = Configuration::get('MULTISAFEPAY_EROTIEKBON_API_KEY');
        $helper->fields_value['MULTISAFEPAY_EROTIEKBON_SANDBOX']    = Configuration::get('MULTISAFEPAY_EROTIEKBON_SANDBOX');
        return $output.$helper->generateForm($fields_form);

    }
}
