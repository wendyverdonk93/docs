<?php
/**
 *  MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@MultiSafepay.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

class CheckConnection
{

    public function __construct ($api, $test_mode)
    {
        if ($api == '') {
            return;
        }
        // Test with current mode
        $msg = $this->testConnection($api, $test_mode);
        if ($msg == null) {
            return;
        }

        // Test with oposite mode
        $msg = $this->testConnection($api, !$test_mode);
        if ($msg == null ) {
            return ( ($test_mode ? 'This API-Key belongs to a LIVE-account' : 'This API-Key belongs to a TEST-account'));
        }

        return ( 'Unknown error. Probably the API-Key is not correct. Error-code: ' . $msg);
    }


    public function checkConnection($api, $test_mode){
        return self::__construct ($api, $test_mode);
    }


    private function testConnection ($api, $test_mode){

        $test_order = array(
            "type"         => 'redirect',
            "order_id"     => 'Check Connection-'. time(),
            "currency"     => 'EUR',
            "amount"       => 1,
            "description"  => 'Check Connection-'. time()
        );

        $msp = new Client();
        $msp->setApiKey($api);
        $msp->setApiUrl($test_mode);

		$msg = null;

        try {
            $msp->orders->post($test_order);
            $url = $msp->orders->getPaymentLink();
        } catch (Exception $e) {
            $msg = $e->getMessage();
        }
        return ($msg);
    }
}

?>