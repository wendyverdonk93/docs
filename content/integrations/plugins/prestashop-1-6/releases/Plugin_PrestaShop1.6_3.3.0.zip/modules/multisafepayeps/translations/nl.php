<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_2b8ea948b269cb3598ef556c3445ce89'] = 'MultiSafepay EPS';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_58ec8293d983c993fe00d243ccf3f4d6'] = 'Accepteer EPS betalingen via MultiSafepay';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u de gegevens wilt verwijderen?';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar modules';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_55ca7a82be81e9a65052907de35b9f1a'] = 'Minimaal orderbedrag voor EPS';
$_MODULE['<{multisafepayeps}default-bootstrap>multisafepayeps_c2bb01e71ac288e8470d8f43363dbd06'] = 'Maximaal orderbedrag voor EPS';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_c2c027d8c62500300145c3043546d4c6'] = 'EPS';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_3b61fe9c5dcd3a06e29903b57207485f'] = 'U heeft gekozen om af te rekenen middels EPS';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayeps}default-bootstrap>validation_eps_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayeps}default-bootstrap>payment_c2c027d8c62500300145c3043546d4c6'] = 'EPS';
$_MODULE['<{multisafepayeps}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepayeps}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';