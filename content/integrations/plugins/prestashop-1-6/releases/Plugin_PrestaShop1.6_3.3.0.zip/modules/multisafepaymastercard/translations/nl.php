<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_288aabecf12ba988ee573c2c47a31a0e'] = 'MultiSafepay Mastercard';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_f2c06b3501cab443b9427fa1be26a243'] = 'Accepteer Mastercard betalingen via MultiSafepay';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_d1f5979ac09000c9b06e545d0f3bbed8'] = 'Minimaal orderbedrag voor Mastercard';
$_MODULE['<{multisafepaymastercard}default-bootstrap>multisafepaymastercard_c029b71f68eb6f043de3b1f2a1fdb3e1'] = 'Maximaal orderbedrag voor Mastercard';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_b48167465ffc278e8096a57fb3e5cf24'] = 'Mastercard';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_8fef42593565a77710be5ef88f5e672b'] = 'U heeft gekozen af te rekenen middels Mastercard';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaymastercard}default-bootstrap>validation_mastercard_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaymastercard}default-bootstrap>payment_2fe3351421d198ea6d3c4a4a0358d08f'] = 'MasterCard';
$_MODULE['<{multisafepaymastercard}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaymastercard}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';