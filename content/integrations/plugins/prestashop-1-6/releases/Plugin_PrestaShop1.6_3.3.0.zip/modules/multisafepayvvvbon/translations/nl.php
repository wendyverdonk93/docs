<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_6ba0d095297174421665a03471760cd1'] = 'MultiSafepay VVV-Bon';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_6ab8974d4459d198f0b38a3b2e1dcae2'] = 'Accepteer VVV-Bon betalingen via MultiSafepay';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_8af703b2bf59cc9742883ae7f4cb0e5b'] = 'Instellingen account';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_d876ff8da67c3731ae25d8335a4168b4'] = 'API-Sleutel';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_6e147eeb6094904219d0987806735f5c'] = 'De API-Sleutel van de betreffende website in het MultiSafepay account. Indien leeg, dan wordt de API-Sleutel van de Standaard MultiSafepay configuratie gebruikt.';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_b02b464fbe0b40f0c481f17894f66747'] = 'Test account';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_138780f997031206bb8ee5390e36e08a'] = 'Gebruik LIVE-account als de API-Sleutel van een Live-account is. Gebruik TEST-account als de API-Sleutel van een Test-account is.';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>multisafepayvvvbon_638ce87fab4d636ed19f2517b40a48fd'] = 'Live account';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_f6b079f131ac5b6e79a71a1355026f6d'] = 'VVV-Bon';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_092ff8a97d06d6f00090315f7f13b830'] = 'U heeft gekozen om af te rekenen middels VVV-Bon';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>validation_vvvbon_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayvvvbon}default-bootstrap>payment_f6b079f131ac5b6e79a71a1355026f6d'] = 'VVV-Bon';