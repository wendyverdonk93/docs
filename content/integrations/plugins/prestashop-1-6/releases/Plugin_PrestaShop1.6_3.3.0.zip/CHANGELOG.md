## 3.3.0
Release date: Feb 26th, 2020

### Fixed
+ PLGPRSS-309: Prevent multiple transactions being created for the same order
+ PLGPRSS-391: Prevent duplicated orders by adding file locking
+ PLGPRSS-267: Mobile presentation of payment methods is not fully responsive

### Changed
+ PLGPRSS-190: Send shopping cart data for all payment methods
+ PLGPRSS-352: Improve parsing of address into street and apartment
