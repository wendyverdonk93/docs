<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_60a9685b3c43c618cfb45a5e46d9cd83'] = 'MultiSafepay BanContact';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_d09efdce634a22b307c926d4d854506b'] = 'Accepteer BanContact betalingen via MultiSafepay';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_e4511a9a6713ee32456cb40e70b739f8'] = 'Minimaal orderbedrag voor BanCcontact';
$_MODULE['<{multisafepaybancontact}default-bootstrap>multisafepaybancontact_6a71dd3d5c0f3573701ad981ecdf25dd'] = 'Maximaal orderbedrag voor BanContact';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_870cf6bc77bbadd038aeb8d942c9cb18'] = 'BanContact';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_8cca2ab5daef01a411bdf52d506da621'] = 'U heeft gekozen af te rekenen met BanContact';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaybancontact}default-bootstrap>validation_mistercash_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaybancontact}default-bootstrap>payment_870cf6bc77bbadd038aeb8d942c9cb18'] = 'BanContact';
$_MODULE['<{multisafepaybancontact}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaybancontact}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';
