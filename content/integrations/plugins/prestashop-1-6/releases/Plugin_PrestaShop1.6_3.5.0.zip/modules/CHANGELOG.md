## 3.5.0
Release date: Apr 9th, 2020

### Added
+ PLGPRSS-344: Add AfterPay

### Fixed
+ PLGPRSS-396: Correct spelling of ING Home'Pay
+ PLGPRSS-397: Fix incorrect gateway code for ING Home'Pay

***

## 3.4.0
Release date: Apr 2nd, 2020

### Added
+ PLGPRSS-400: Add Apple Pay
+ PLGPRSS-399: Add Direct Bank Transfer

***

## 3.3.0
Release date: Feb 26th, 2020

### Fixed
+ PLGPRSS-309: Prevent multiple transactions being created for the same order
+ PLGPRSS-391: Prevent duplicated orders by adding file locking
+ PLGPRSS-267: Mobile presentation of payment methods is not fully responsive

### Changed
+ PLGPRSS-190: Send shopping cart data for all payment methods
+ PLGPRSS-352: Improve parsing of address into street and apartment
