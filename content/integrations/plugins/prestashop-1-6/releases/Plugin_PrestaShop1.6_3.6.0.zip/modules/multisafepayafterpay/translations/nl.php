<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_04ffc3e9a3a530eb491d56ea3296b945'] = 'AfterPay';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_d670196c5f2dd031b084d0a2cc0e6c02'] = 'Accepteer AfterPay betalingen via MultiSafepay';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_eb29bf7e9277519aebbd56f78e140d65'] = 'Minimaal orderbedrag voor AfterPay';
$_MODULE['<{multisafepayafterpay}default-bootstrap>multisafepayafterpay_32a632726609aba61e6139ac1699c3b4'] = 'Maximaal orderbedrag voor AfterPay';
