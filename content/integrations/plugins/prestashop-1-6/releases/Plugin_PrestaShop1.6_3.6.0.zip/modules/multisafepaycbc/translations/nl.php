<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaycbc}default-bootstrap>multisafepaycbc_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaycbc}default-bootstrap>multisafepaycbc_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaycbc}default-bootstrap>multisafepaycbc_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaycbc}default-bootstrap>multisafepaycbc_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaycbc}default-bootstrap>multisafepaycbc_604d0ba5580e9ddcfbda09fbdf32a62c'] = 'Minimaal orderbedrag voor CBC';
$_MODULE['<{multisafepaycbc}default-bootstrap>multisafepaycbc_7e564da0c60fe80936d0a4a27d79ed24'] = 'Maximaal orderbedrag voor CBC';
