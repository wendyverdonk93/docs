<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_2aaa01dc81514bfb1d03668d0dc5366b'] = 'MultiSafepay iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_6d888f270b2cc5ea1fe7490ae4333761'] = 'Accepteer iDEAL betalingen via MultiSafepay';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_c5ddab2a7bb11a7ee8f5a131db40bfae'] = 'Selecteer uw bank';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_52f4393e1b52ba63e27310ca92ba098c'] = 'Algemene instellingen';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_93254eb0eed6a680aecc9378144e5187'] = 'Direct iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nee';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_5a87a97d88b8b29555600d9710db8ff0'] = 'Minimaal orderbedrag voor iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>multisafepayideal_4803ab45fe488ed99bf82f77e03661cf'] = 'Maximaal orderbedrag voor iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_f91ab041fe9d6057740394b8b7903a0f'] = 'iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_4f9fd5b4dd388854659b0a31869853da'] = 'U heeft gekozen om af te rekenen middels iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayideal}default-bootstrap>validation_ideal_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayideal}default-bootstrap>payment_f91ab041fe9d6057740394b8b7903a0f'] = 'iDEAL';
$_MODULE['<{multisafepayideal}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepayideal}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';
$_MODULE['<{multisafepayideal}default-bootstrap>payment_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';