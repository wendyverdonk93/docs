<?php
/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@multisafepay.com.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */


class MultisafepayNotificationModuleFrontController extends ModuleFrontController
{
    public $order_id;
    public $states;
    public $statussen;
    public $cart_id;
    public $secure_key;
    public $paid;
    public $initial;
    public $transactie;
    public $status;

    public function initContent()
    {

        $transactionid = Tools::getValue('transactionid');

        $lockLocation = _PS_MODULE_DIR_ . 'multisafepay/locks/' . $transactionid .'.lock';

        $lock = new Msp_Lock($lockLocation);

        if ($lock->isLockActive(5)) {
            die('ng');
        }

        $lock->lock();

        if ( Tools::getValue('timestamp') ){

            $this->statussen = array ( 'new_order'         => Configuration::get('MULTISAFEPAY_OS_NEW_ORDER'),
                                       'initialized'       => Configuration::get('MULTISAFEPAY_OS_INITIALIZED'),
                                       'completed'         => Configuration::get('MULTISAFEPAY_OS_COMPLETED'),
                                       'uncleared'         => Configuration::get('MULTISAFEPAY_OS_UNCLEARED'),
                                       'cancelled'         => Configuration::get('MULTISAFEPAY_OS_CANCELLED'),
                                       'void'              => Configuration::get('MULTISAFEPAY_OS_VOID'),
                                       'declined'          => Configuration::get('MULTISAFEPAY_OS_DECLINED'),
                                       'refunded'          => Configuration::get('MULTISAFEPAY_OS_REFUNDED'),
                                       'partial_refunded'  => Configuration::get('MULTISAFEPAY_OS_PARTIAL_REFUNDED'),
                                       'expired'           => Configuration::get('MULTISAFEPAY_OS_EXPIRED'),
                                       'shipped'           => Configuration::get('MULTISAFEPAY_OS_SHIPPED')
                                     );

            $msp = new Client();

            if (isset ($this->api)) {
                // Use API/ mode from the specific gateway configuration
                $api = $this->api;
                $mode = $this->mode;
            } else {
                // Use API/ mode from the default configuration
                $api  = Configuration::get('MULTISAFEPAY_API_KEY');
                $mode = Configuration::get('MULTISAFEPAY_SANDBOX');
            }
            $msp->setApiKey($api);
            $msp->setApiUrl($mode);

            try {
                $this->transactie = $msp->orders->get($transactionid, 'orders', array(), false);
            } catch (Exception $e) {

                $msg = sprintf ("%s %s", htmlspecialchars($e->getMessage()), $transactionid);
                PrestaShopLogger::addLog($msg, 4, '', 'MultiSafepay', 'MSP', 'MSP');
                $lock->unlock();
                die('ng');
            }

            
            // Test if transaction exist
            if ($this->transactie->order_id){
                $extra_data             = Tools::jsonDecode($this->transactie->var1);

                $this->cart_id          = $extra_data->id_cart;
                $this->secure_key       = $this->transactie->var2;
                $this->paid             = $this->transactie->amount /100;
                $this->order_id         = $this->transactie->order_id;
                $this->status           = $this->transactie->status;
                $this->transaction_id   = $this->transactie->transaction_id;

                // If timestamp or type=redirect, process, otherwise not
                if (Tools::getValue('timestamp') || Tools::getValue('type') == 'redirect') {

                    switch (Configuration::get('MULTISAFEPAY_WHEN_CREATE_ORDER'))
                    {
                      case 'After_Confirmation':
                          $this->afterConfirmation();
                          break;

                      case 'After_Payment_Complete':
                          $this->afterPaymentComplete();
                          break;

                      case 'After_Payment_Complete_Inc_Banktrans':
                          $this->afterPaymentCompleteIncBanktrans();
                          break;
                    }
                }
            }
        }

        $lock->unlock();


        switch ( Tools::getValue('type') ) {
            case 'initial':
                die();
            case 'redirect':
                Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)($this->cart_id).'&id_module='.(int)($this->module->id).'&id_order='.$this->order_id.'&key='.$this->secure_key);
                break;

            case 'cancel':
            
            
	            $msp = new Client();
	            if (isset ($this->api)) {
	                // Use API/ mode from the specific gateway configuration
	                $api = $this->api;
	                $mode = $this->mode;
	            } else {
	                // Use API/ mode from the default configuration
	                $api  = Configuration::get('MULTISAFEPAY_API_KEY');
	                $mode = Configuration::get('MULTISAFEPAY_SANDBOX');
	            }
	            $msp->setApiKey($api);
	            $msp->setApiUrl($mode);

	            try {
	                $this->transactie = $msp->orders->get($transactionid, 'orders', array(), false);
	            } catch (Exception $e) {

                        $msg = sprintf ("%s %s", htmlspecialchars($e->getMessage()), $transactionid);
                        PrestaShopLogger::addLog($msg, 4, '', 'MultiSafepay', 'MSP', 'MSP');
	            }


                // Test if transaction exist
                if ($this->transactie->order_id){

                    $var1    = Tools::jsonDecode($this->transactie->var1);
                    $cart_id = $var1->id_cart;
     
                    $lastCart = new Cart($cart_id);
                    $newCart = $lastCart->duplicate();

                    if (!$newCart || !Validate::isLoadedObject($newCart['cart']))
                        $errors[] = Tools::displayError('Sorry. We cannot renew your order.');
                    else if (!$newCart['success'])
                        $errors[] = Tools::displayError('Some items are no longer available, and we are unable to renew your order.');
                    else
                    {
                        $this->context->cookie->id_cart = $newCart['cart']->id;
                        $this->context->cookie->write();
                    }
                }
                
                $errors[] = Tools::displayError('Error during payment.');
                $errors[] = Tools::displayError('Please try again..');

                $this->context->cookie->msp_error = serialize($errors);
                $this->context->cookie->write();

                
                $url = "index.php?controller=order&step=3";

                /* adviva */
                $id_cancelled_cart = Tools::getValue('id_cancel_cart');
                if(isset($id_cancelled_cart)){
                    $this->postProcessTokenization($id_cancelled_cart);
                }
                /* adviva */


                Tools::redirect($url);
                exit;

            default:
                die ('ok');
        }
    }


    private function afterConfirmation()
    {
        $this->updateOrder();
    }

    private function afterCheckoutComplete()
    {
        $this->updateOrCreateOrder();
    }

    private function afterPaymentComplete()
    {
        if ( $this->status == 'completed') {
            $this->updateOrCreateOrder();
        }
        if ($this->transactie->payment_details->type == 'BANKTRANS'){
           $this->context->cart->delete();
        }

    }

    private function afterPaymentCompleteIncBanktrans()
    {
        if ($this->status == 'completed' || $this->transactie->payment_details->type == 'BANKTRANS') {
            $this->updateOrCreateOrder();
        }

        if ($this->transactie->payment_details->type == 'BANKTRANS'){
            $this->context->cart->delete();
        }
    }

    private function updateOrCreateOrder()
    {
        if ($this->cart_id && Order::getOrderByCartId((int)$this->cart_id)){
            $this->updateOrder();
        }else{
            $this->createOrder();
        }
    }

    private function updateOrder()
    {
        // Order should already exists
        $order = new Order(Order::getOrderByCartId((int)$this->cart_id));

        $history = new OrderHistory();
        $history->id_order = (int)$order->id;

        // If current order-state is not a MultiSafepay order-state, then do not update the status anymore.
        if ( !array_search($order->getCurrentState(), $this->statussen)){
            return;
        }

        if ($order->getCurrentState() != $this->statussen[$this->status]) {

            $history->changeIdOrderState((int)$this->statussen[$this->status], $order->id);
            $history->add();
        }

        if ($this->status == 'completed') {
            $payments = $order->getOrderPaymentCollection();
            $payments[0]->transaction_id = $this->transaction_id;
            $payments[0]->update();
        }


    }

    private function createOrder()
    {
        $msg = 'MultiSafepay reference: '       . $this->order_id;
        $this->module->validateOrder((int)$this->cart_id, $this->statussen[$this->status], $this->paid, $this->module->displayName, $msg, array(), null, false, $this->secure_key);
//        Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)($this->cart_id).'&id_module='.(int)($this->module->id).'&id_order='.$this->order_id.'&key='.$this->secure_key);
    }


	/* adviva */
    private function postProcessTokenization($id_cart)
    {
        $tokenRow = Db::getInstance()->getRow("SELECT * FROM "._DB_PREFIX_.Configuration::get('MULTISAFEPAY_TOKENIZATION_TABLE_NAME')." where `id_cart` = ".(int)$id_cart);
        if($tokenRow && isset($tokenRow["id_cart"])){
            if(!Db::getInstance()->update(
                Configuration::get('MULTISAFEPAY_TOKENIZATION_TABLE_NAME'),
                array(
                    'token'=> Configuration::get('MULTISAFEPAY_TOKENIZATION_NOT_USED_CONT')
                ),
                'id_cart = '.$id_cart
            )){
                if (Configuration::get('MULTISAFEPAY_DEBUG_MODE')) {
                    $msg = '[MULTISAFEPAY] Token not updated correctly. Cart id was: '.$id_cart;
                    PrestaShopLogger::addLog($msg, 3);
                    $logger = new FileLogger(0);
                    $logger->setFilename(_PS_ROOT_DIR_.'/log/MultiSafepay.log');
                    $logger->logDebug($msg);
                }
            }
        }
    }
}
