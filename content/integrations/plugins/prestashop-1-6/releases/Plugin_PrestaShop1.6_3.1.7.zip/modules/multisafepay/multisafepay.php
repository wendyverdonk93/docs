<?php

/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@multisafepay.com.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */
require_once (_PS_MODULE_DIR_.'multisafepay/api/Autoloader.php');
require_once (_PS_MODULE_DIR_.'multisafepay/helpers/Autoloader.php');

if (!defined('_PS_VERSION_')) {
    exit;
}

class MultiSafepay extends PaymentModule
{
    public function __construct()
    {
        $this->name                     = 'multisafepay';
        $this->tab                      = 'payments_gateways';
        $this->version                  = '3.1.7';
        $this->author                   = 'MultiSafepay';

        $this->need_instance            = 1;
        $this->ps_versions_compliancy   = array('min' => '1.6', 'max' => '1.6');

        $this->currencies               = true;
        $this->currencies_mode          = 'checkbox';

        $this->module_key               = '54635c1e3a467c329ab7494101b6bfc4';
        $this->bootstrap                = true;
        parent::__construct();

        $this->displayName              = $this->l('MultiSafepay');
        $this->description              = $this->l('Accept payments by MultiSafepay');
        $this->confirmUninstall         = $this->l('Are you sure you want to delete your details?');


    }

    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('orderConfirmation')   ||
			!$this->registerHook('displayOrderConfirmation') ||
            !$this->registerHook('displayPaymentTop')  ) {
            return false;
        }

        Configuration::updateValue('MULTISAFEPAY_NAME'              , 'MultiSafepay');
        Configuration::updateValue('MULTISAFEPAY_SANDBOX'           , true);
        Configuration::updateValue('MULTISAFEPAY_API_KEY'           , '');
        Configuration::updateValue('MULTISAFEPAY_TIME_ACTIVE'       , '30');
        Configuration::updateValue('MULTISAFEPAY_TIME_LABEL'        , 'days');
        Configuration::updateValue('MULTISAFEPAY_NURL_MODE'         , 'DEFAULT');
        Configuration::updateValue('MULTISAFEPAY_DEBUG_MODE'        , false);
        Configuration::updateValue('MULTISAFEPAY_EXTRA_CONFIRM'     , false);
        Configuration::updateValue('MULTISAFEPAY_WHEN_CREATE_ORDER' , 'After_Confirmation');


        $multisafepay_stats =  array(
            'new_order'         => array( 'new_order',          false,  '#4169e1',  false,  '',                 false,  false),
            'initialized' 	    => array( 'initialized',        false,  '#ff8c00',  false,  '',                 false,  false),
            'completed' 	    => array( 'completed',          true,   '#32cd32',  true,   'payment',          true,   true ),
            'uncleared' 	    => array( 'uncleared',          false,  '#32cd32',  false,  '',                 false,  false),
            'void' 			    => array( 'void',               true,   '#dc143c',  false,  'order_canceled',   false,  false),
            'cancelled' 	    => array( 'cancelled',          true,   '#dc143c',  false,  'order_canceled',   false,  false),
            'expired' 		    => array( 'expired',            false,  '#dc143c',  false,  '',                 false,  false),
            'declined' 		    => array( 'declined',           false,  '#8f0621',  false,  '',                 false,  false),
            'shipped' 		    => array( 'shipped',            false,  '#8f0621',  false,  '',                 false,  false),
            'refunded' 		    => array( 'refunded',           true,   '#ec2e15',  false,  'refund',           false,  false),
            'partial_refunded'  => array( 'partial_refunded',   true,   '#ec2e15',  false,  'refund',           false,  false)
        );

        foreach ($multisafepay_stats as $status => $value) {
            if (!Configuration::get('MULTISAFEPAY_OS_'.Tools::strtoupper($status))) {
                $order_state        = new OrderState();
                $order_state->name  = array();
                foreach (Language::getLanguages() as $language) {
                    $order_state->name[$language['id_lang']] = 'MultiSafepay '.$value[0];
                }

                $order_state->send_email = $value[1];
                $order_state->color      = $value[2];
                $order_state->invoice    = $value[3];
                $order_state->template   = $value[4];
                $order_state->paid       = $value[5];
                $order_state->logable    = $value[6];
                $order_state->hidden     = false;
                $order_state->delivery   = false;

                $order_state->add();
                Configuration::updateValue('MULTISAFEPAY_OS_'.Tools::strtoupper($status), (int)$order_state->id);
            }
        }


        return true;
    }

    public function uninstall()
    {
        Configuration::deleteByName('MULTISAFEPAY_NAME');
        Configuration::deleteByName('MULTISAFEPAY_SANDBOX');
        Configuration::deleteByName('MULTISAFEPAY_API_KEY');

        Configuration::deleteByName('MULTISAFEPAY_EXTRA_CONFIRM');
        Configuration::deleteByName('MULTISAFEPAY_WHEN_CREATE_ORDER');

        Configuration::deleteByName('MULTISAFEPAY_DEBUG_MODE');
        Configuration::deleteByName('MULTISAFEPAY_TIME_ACTIVE');
        Configuration::deleteByName('MULTISAFEPAY_TIME_LABEL');
        Configuration::deleteByName('MULTISAFEPAY_NURL_MODE');

        // Needed to remove older versions of the plugin.
        Configuration::deleteByName('MULTISAFEPAY_DAYS_ACTIVE');
        Configuration::deleteByName('MULTISAFEPAY_ORDER_CONFIRM_BEFORE');
        Configuration::deleteByName('MULTISAFEPAY_ORDER_CONFIRM_PAID');
        Configuration::deleteByName('MULTISAFEPAY_ACCOUNT_ID');
        Configuration::deleteByName('MULTISAFEPAY_SITE_SECURE_CODE');
        Configuration::deleteByName('MULTISAFEPAY_SITE_ID');
        Configuration::deleteByName('MULTISAFEPAY_SEND_CONFIRMATION');

        return parent::uninstall();
    }

    public function getContent()
    {
        $output = null;
        if (Tools::isSubmit('submit'.$this->name)) {
            Configuration::updateValue('MULTISAFEPAY_API_KEY',              Tools::getValue('MULTISAFEPAY_API_KEY'));
            Configuration::updateValue('MULTISAFEPAY_SANDBOX',              Tools::getValue('MULTISAFEPAY_SANDBOX'));
            Configuration::updateValue('MULTISAFEPAY_EXTRA_CONFIRM',        Tools::getValue('MULTISAFEPAY_EXTRA_CONFIRM'));
            Configuration::updateValue('MULTISAFEPAY_WHEN_CREATE_ORDER',    Tools::getValue('MULTISAFEPAY_WHEN_CREATE_ORDER'));
            Configuration::updateValue('MULTISAFEPAY_TIME_ACTIVE',          Tools::getValue('MULTISAFEPAY_TIME_ACTIVE'));
            Configuration::updateValue('MULTISAFEPAY_TIME_LABEL',           Tools::getValue('MULTISAFEPAY_TIME_LABEL'));
            Configuration::updateValue('MULTISAFEPAY_NURL_MODE',            Tools::getValue('MULTISAFEPAY_NURL_MODE'));
            Configuration::updateValue('MULTISAFEPAY_SECONDS_ACTIVE',       Tools::getValue('MULTISAFEPAY_SECONDS_ACTIVE'));
            Configuration::updateValue('MULTISAFEPAY_DEBUG_MODE',           Tools::getValue('MULTISAFEPAY_DEBUG_MODE'));
            Configuration::updateValue('MULTISAFEPAY_OS_NEW_ORDER',         Tools::getValue('MULTISAFEPAY_OS_NEW_ORDER'));
            Configuration::updateValue('MULTISAFEPAY_OS_INITIALIZED',       Tools::getValue('MULTISAFEPAY_OS_INITIALIZED'));
            Configuration::updateValue('MULTISAFEPAY_OS_COMPLETED',         Tools::getValue('MULTISAFEPAY_OS_COMPLETED'));
            Configuration::updateValue('MULTISAFEPAY_OS_UNCLEARED',         Tools::getValue('MULTISAFEPAY_OS_UNCLEARED'));
            Configuration::updateValue('MULTISAFEPAY_OS_CANCELLED',         Tools::getValue('MULTISAFEPAY_OS_CANCELLED'));
            Configuration::updateValue('MULTISAFEPAY_OS_VOID',              Tools::getValue('MULTISAFEPAY_OS_VOID'));
            Configuration::updateValue('MULTISAFEPAY_OS_EXPIRED',           Tools::getValue('MULTISAFEPAY_OS_EXPIRED'));
            Configuration::updateValue('MULTISAFEPAY_OS_DECLINED',          Tools::getValue('MULTISAFEPAY_OS_DECLINED'));
            Configuration::updateValue('MULTISAFEPAY_OS_REFUNDED',          Tools::getValue('MULTISAFEPAY_OS_REFUNDED'));
            Configuration::updateValue('MULTISAFEPAY_OS_PARTIAL_REFUNDED',  Tools::getValue('MULTISAFEPAY_OS_PARTIAL_REFUNDED'));
            Configuration::updateValue('MULTISAFEPAY_OS_SHIPPED',           Tools::getValue('MULTISAFEPAY_OS_SHIPPED'));


            $CheckConnection = new CheckConnection('', '');
            $check = $CheckConnection->checkConnection( Tools::getValue('MULTISAFEPAY_API_KEY'),
                                                        Tools::getValue('MULTISAFEPAY_SANDBOX'));
            if ($check) {
                $output = $this->displayError($check);
            }

            switch (Tools::getValue('MULTISAFEPAY_TIME_LABEL')){
                case 'days':
                    $seconds_active = Tools::getValue('MULTISAFEPAY_TIME_ACTIVE')*24*60*60;
                    break;
                  case 'hours':
                    $seconds_active = Tools::getValue('MULTISAFEPAY_TIME_ACTIVE')*60*60;
                    break;
                case 'seconds':
                    $seconds_active = Tools::getValue('MULTISAFEPAY_TIME_ACTIVE');
                    break;
            }
            Configuration::updateValue('MULTISAFEPAY_SECONDS_ACTIVE', $seconds_active);



            if ($output == null) {
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $helper = new HelperForm();
        $helper->module                    = $this;
        $helper->name_controller           = $this->name;
        $helper->token                     = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex              = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language     = $default_lang;
        $helper->allow_employee_form_lang  = $default_lang;
        $helper->title                     = $this->displayName;
        $helper->show_toolbar              = true;
        $helper->toolbar_scroll            = true;
        $helper->submit_action             = 'submit'.$this->name;
        $helper->toolbar_btn               = array('save' => array(
                                                       'desc' => $this->l('Save'),
                                                       'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules')
                                                   ),
                                                   'back' => array(
                                                       'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
                                                       'desc' => $this->l('Back to list')
                                                    ));



        $order_states_db = OrderState::getOrderStates($this->context->language->id);
        $order_states = array();
        foreach ($order_states_db as $order_state) {
            $order_states[] = array(
                                'id'   => $order_state['id_order_state'],
                                'name' => $order_state['name']
                              );
        }

        $fields_form            = array();
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Account Settings'),
                'image' => '../img/admin/edit.gif'
            ),
            'input' => array(
                array(
                    'type'          =>  'text',
                    'label'         =>  $this->l('API Key'),
                    'name'          =>  'MULTISAFEPAY_API_KEY',
                    'size'          =>  20,
                    'required'      =>  true,
                    'hint'          =>  $this->l('The API-Key from the corresponding website in your MultiSafepay account'),
                ),

                array(
                    'type'          =>  'switch',
                    'label'         =>  $this->l('Test account'),
                    'name'          =>  'MULTISAFEPAY_SANDBOX',
                    'class'         =>  't',
                    'is_bool'       =>  true,
                    'required'      =>  true,
                    'hint'          =>  $this->l('Use Live-account the API-Key is from your MultiSafepay LIVE-account.<br/>Use Test -account if the API-Key is from your MultiSafepay TEST-account.'),
                    'values'        =>  array(
                                            array(
                                                'id'    => 'test',
                                                'value' => true,
                                                'label' => $this->l('Test account')
                                            ),
                                            array(
                                                'id'    => 'prod',
                                                'value' => false,
                                                'label' => $this->l('Live account')
                                            )
                                        )
                )
             )
        );

        $fields_form[1]['form'] = array(
            'legend' => array(
                'title' => $this->l('General Settings'),
                'image' => '../img/admin/edit.gif'
            ),
            'input' => array(
                array(
                    'type'          =>  'switch',
                    'label'         =>  $this->l('Extra confirmation before payment'),
                    'name'          =>  'MULTISAFEPAY_EXTRA_CONFIRM',
                    'class'         =>  't',
                    'is_bool'       =>  true,
                    'hint'          =>  $this->l('Show the extra payment confirmation screen. '),
                    'values'        =>  array(
                                            array(
                                                'id'    => 'yes',
                                                'value' => true,
                                                'label' => $this->l('Yes')
                                            ),
                                            array(
                                                'id'    => 'no',
                                                'value' => false,
                                                'label' => $this->l('No')
                                            )
                                        )
                ),

                array(
                    'type'          =>  'switch',
                    'label'         =>  $this->l('Debug'),
                    'name'          =>  'MULTISAFEPAY_DEBUG_MODE',
                    'class'         =>  't',
                    'required'      =>  false,
                    'is_bool'       =>  true,
                    'hint'          =>  $this->l('Use to debug into the MultiSafepay logfile.'),
                    'values'        =>  array(
                                            array(
                                                'id'    => 'true',
                                                'value' => true,
                                                'label' => $this->l('Yes')
                                            ),
                                            array(
                                                'id'    => 'false',
                                                'value' => false,
                                                'label' => $this->l('No')
                                            )
                                        )
                ),

                array(
                    'type'          =>  'text',
                    'class'         => 'fixed-width-sm',
                    'label'         =>  $this->l('Time an order stays active'),
                    'hint'          =>  $this->l('Time an order stays active before the orderstatus is set to expired'),
                    'name'          =>  'MULTISAFEPAY_TIME_ACTIVE',
                    'required'      =>  false
                ),

                array(
                    'type'          =>  'select',
                    'name'          =>  'MULTISAFEPAY_TIME_LABEL',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => array(   array ( 'id'   => 'days',       'name' => $this->l('Days')),
                                                                array ( 'id'   => 'hours',      'name' => $this->l('Hours')),
                                                                array ( 'id'   => 'seconds',    'name' => $this->l('Seconds'))
                                                ),
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),

                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Protocol '),
                    'name'          =>  'MULTISAFEPAY_NURL_MODE',
                    'required'      =>  false,
                    'hint'          =>  $this->l('Use Default, HTTP or HTTPS for the offline actions?'),
                    'options'       =>  array(

                                            'query' => array(   array ( 'id'   => 'DEFAULT',  'name' => $this->l('Use PrestaShop settings')),
                                                                array ( 'id'   => 'HTTP',     'name' => $this->l('Use Http')),
                                                                array ( 'id'   => 'HTTPS',    'name' => $this->l('Use Https'))

                                                ),
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),

                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Moment of order creation'),
                    'name'          =>  'MULTISAFEPAY_WHEN_CREATE_ORDER',
                    'required'      =>  false,
                    'hint'          =>  $this->l('At what moment should the orders be created?'),
                    'options'       =>  array(

                                            'query' => array(   array ( 'id'   => 'After_Confirmation',                     'name' => $this->l('After order is confirmed')),
                                                                array ( 'id'   => 'After_Payment_Complete',                 'name' => $this->l('After order is paid in full')),
                                                                array ( 'id'   => 'After_Payment_Complete_Inc_Banktrans',   'name' => $this->l('After order is paid in full or by banktransfer'))

                                                ),
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                )
            )
        );

        $fields_form[2]['form'] = array(
            'legend' => array(
                'title' => $this->l('Status Settings'),
                'image' => '../img/admin/edit.gif'
            ),
            'input' => array(


                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('New order'),
                    'name'          =>  'MULTISAFEPAY_OS_NEW_ORDER',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Initialized'),
                    'name'          =>  'MULTISAFEPAY_OS_INITIALIZED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Completed'),
                    'name'          =>  'MULTISAFEPAY_OS_COMPLETED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Uncleared'),
                    'name'          =>  'MULTISAFEPAY_OS_UNCLEARED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name' => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Void'),
                    'name'          =>  'MULTISAFEPAY_OS_VOID',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Cancelled'),
                    'name'          =>  'MULTISAFEPAY_OS_CANCELLED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Expired'),
                    'name'          =>  'MULTISAFEPAY_OS_EXPIRED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name' => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Declined'),
                    'name'          =>  'MULTISAFEPAY_OS_DECLINED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Refunded'),
                    'name'          =>  'MULTISAFEPAY_OS_REFUNDED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                            )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Partial Refunded'),
                    'name'          =>  'MULTISAFEPAY_OS_PARTIAL_REFUNDED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
                array(
                    'type'          =>  'select',
                    'label'         =>  $this->l('Shipped'),
                    'name'          =>  'MULTISAFEPAY_OS_SHIPPED',
                    'required'      =>  false,
                    'options'       =>  array(
                                            'query' => $order_states,
                                            'id'    => 'id',
                                            'name'  => 'name'
                                        )
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper->fields_value['MULTISAFEPAY_API_KEY']             = Configuration::get('MULTISAFEPAY_API_KEY');
        $helper->fields_value['MULTISAFEPAY_SANDBOX']             = Configuration::get('MULTISAFEPAY_SANDBOX');
        $helper->fields_value['MULTISAFEPAY_EXTRA_CONFIRM']       = Configuration::get('MULTISAFEPAY_EXTRA_CONFIRM');
        $helper->fields_value['MULTISAFEPAY_WHEN_CREATE_ORDER']   = Configuration::get('MULTISAFEPAY_WHEN_CREATE_ORDER');
        $helper->fields_value['MULTISAFEPAY_OS_NEW_ORDER']        = Configuration::get('MULTISAFEPAY_OS_NEW_ORDER');
        $helper->fields_value['MULTISAFEPAY_OS_INITIALIZED']      = Configuration::get('MULTISAFEPAY_OS_INITIALIZED');
        $helper->fields_value['MULTISAFEPAY_OS_COMPLETED']        = Configuration::get('MULTISAFEPAY_OS_COMPLETED');
        $helper->fields_value['MULTISAFEPAY_OS_UNCLEARED']        = Configuration::get('MULTISAFEPAY_OS_UNCLEARED');
        $helper->fields_value['MULTISAFEPAY_OS_VOID']             = Configuration::get('MULTISAFEPAY_OS_VOID');
        $helper->fields_value['MULTISAFEPAY_OS_CANCELLED']        = Configuration::get('MULTISAFEPAY_OS_CANCELLED');
        $helper->fields_value['MULTISAFEPAY_OS_EXPIRED']          = Configuration::get('MULTISAFEPAY_OS_EXPIRED');
        $helper->fields_value['MULTISAFEPAY_OS_DECLINED']         = Configuration::get('MULTISAFEPAY_OS_DECLINED');
        $helper->fields_value['MULTISAFEPAY_OS_REFUNDED']         = Configuration::get('MULTISAFEPAY_OS_REFUNDED');
        $helper->fields_value['MULTISAFEPAY_OS_PARTIAL_REFUNDED'] = Configuration::get('MULTISAFEPAY_OS_PARTIAL_REFUNDED');
        $helper->fields_value['MULTISAFEPAY_OS_SHIPPED']          = Configuration::get('MULTISAFEPAY_OS_SHIPPED');
        $helper->fields_value['MULTISAFEPAY_TIME_ACTIVE']         = Configuration::get('MULTISAFEPAY_TIME_ACTIVE');
        $helper->fields_value['MULTISAFEPAY_TIME_LABEL']          = Configuration::get('MULTISAFEPAY_TIME_LABEL');
        $helper->fields_value['MULTISAFEPAY_NURL_MODE']           = Configuration::get('MULTISAFEPAY_NURL_MODE');
        $helper->fields_value['MULTISAFEPAY_DEBUG_MODE']          = Configuration::get('MULTISAFEPAY_DEBUG_MODE');

        return $output.$helper->generateForm($fields_form);
    }

    private function isMultiSafepay($id_module){
        foreach (Module::getPaymentModules() as $module){
            if ( $module['id_module'] == $id_module && strpos($module['name'], 'multisafepay') !== false)
                return (true);
        }
        return (false);
    }

	public function checkCurrency($cart)
	{
		$currency_order = new Currency((int)($cart->id_currency));
		$currencies_module = $this->getCurrency((int)$cart->id_currency);

		if (is_array($currencies_module))
			foreach ($currencies_module as $currency_module)
				if ($currency_order->id == $currency_module['id_currency'])
					return true;
		return false;
	}

    public function hookdisplayPaymentTop()
    {
        if (!$this->active || !Tools::getValue('msp_error'))
            return;

        $this->context->smarty->assign(array(
           'errorMessage' => Tools::getValue('msp_error'),
           'module'       => "multisafepay"
        ));

        return $this->display(__FILE__, 'error.tpl');
    }

    public function hookDisplayOrderConfirmation($params){

        if ($this->context->customer->is_guest)
            return ('');
        else
            return ('<h4>'.  $this->l('Thank you. Your order has been received.') . '</h4>' .
                      '<p>'.   $this->l('Your order ID is:') . '<span class="bold">'. sprintf('#%06d', $this->context->controller->id_order) . '</span></p>' .
                      '<p>'.   $this->l('Your order ID has been sent via email to: ') . $this->context->customer->email . '</p>');

    }

    public function hookOrderConfirmation()
    {

        if ($this->isMultiSafepay($_GET['id_module']) !== true)
            return;


        // Get the order status
        $msp = new Client;
        $msp->setApiKey(Configuration::get('MULTISAFEPAY_API_KEY'));
        $msp->setApiUrl(Configuration::get('MULTISAFEPAY_SANDBOX'));
        $transactionid = $_GET['id_order'];

        // Get the order status
        try {
            $transaction = $msp->orders->get($transactionid, 'orders', array(), false);
        } catch (MultiSafepay_API_Exception $e) {
        }
        if ($transaction)
            $status = $transaction->status;
        else
            $status = $this->l('Unknown');


        $this->context->smarty->assign(array(
            'is_guest'  => $this->context->customer->is_guest,
            'params'    => array ( 'status'     => $status,
                                   'order_id'   => $transactionid)
        ));


        /* If guest we clear the cookie for security reason */
        if ($this->context->customer->is_guest)
			$this->context->customer->mylogout();


        return $this->display(__FILE__, 'order-confirmation.tpl');
    }

}

