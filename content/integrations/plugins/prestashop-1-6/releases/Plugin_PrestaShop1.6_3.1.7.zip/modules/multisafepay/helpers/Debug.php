<?php
/**
 *  MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@MultiSafepay.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

class Debug
{
    public $msg;
    public function __construct($msg)
    {
        if (Configuration::get('MULTISAFEPAY_DEBUG_MODE')) {
            $logger = new FileLogger(0);
            $logger->setFilename(_PS_ROOT_DIR_.'/log/MultiSafepay.log');
            $msg = trim ($msg);
            $logger->logDebug($msg);
        }
    }

    public function debug($msg)
    {
        self::__contruct($msg);
    }
}