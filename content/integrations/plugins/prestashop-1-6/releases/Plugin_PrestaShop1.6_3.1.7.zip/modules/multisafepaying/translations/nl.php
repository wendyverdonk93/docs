<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_ba9f53d8845f765818a9ab5eb6041966'] = 'MultiSafepay ING Home\'Pay';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_ae24b8482adb90ffda9e8489413952b2'] = 'Accepteer ING Home\'Pay betalingen via MultiSafepay';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_fd9dbf2cb1a0f43ff6c5000de38046fa'] = 'Minimaal orderbedrag voor ING Home\'Pay';
$_MODULE['<{multisafepaying}default-bootstrap>multisafepaying_015a95b3eea3ee4f5013da7c592a9367'] = 'Maximaal orderbedrag voor ING Home\'Pay';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_8184c64d6318b4a42428ae21d0fe2311'] = 'ING Home\'Pay';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_c92d9b3be6f785d68372ba1de591d1ee'] = 'U heeft gekozen om af te rekenen middels ING Home\'Pay';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaying}default-bootstrap>validation_ing_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaying}default-bootstrap>payment_8184c64d6318b4a42428ae21d0fe2311'] = 'ING Home\'Pay';
$_MODULE['<{multisafepaying}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaying}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';