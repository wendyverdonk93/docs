<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_e34324ec156dba8eb8a64cb154096381'] = 'MultiSafepay Eenmalige machtiging';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_10ed25653f61baa19f11dc2d591b40bf'] = 'Accepteer Eenmalige machtiging betalingen via MultiSafepay';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_e9a08bb086ce953fdeb01582a4773364'] = 'Minimaal orderbedrag voor Eenmalige machtiging';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>multisafepaydirdeb_8ab5893ec0f52ef4197d5e8241b5b981'] = 'Maximaal orderbedrag voor Eenmalige machtiging';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_7cad7c166dc4816cf05e0125803c85c0'] = 'Incasso';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_dcd1b4ad6be20d77b06d16962cf045e5'] = 'U heeft gekozen af te rekenen middels Eenmalige machtiging';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>validation_dirdeb_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>payment_80ccbf6bc10ab01a0df43589b2361e98'] = 'Eenmalige machtiging';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaydirdeb}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';