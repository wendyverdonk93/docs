# OpenCart
OpenCart plug-in for Opencart 3.x

The MultiSafepay extension for OpenCart allows you to integrate add all paymentmethods and giftcards offered by MultiSafepay into your OpenCart webshop.

When using an older version of Opencart, then please visit Multisafepay.com using:

https://www.multisafepay.com/solutions/shop-plug-ins/detail/plugins/opencart/

And download an older plug-in release