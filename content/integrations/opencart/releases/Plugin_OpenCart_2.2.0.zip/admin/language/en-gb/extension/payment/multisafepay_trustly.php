<?php

$_['heading_title'] = 'MultiSafepay Trustly';

// Text
$_['text_multisafepay_trustly'] = '<a onclick="window.open(\'http://www.multisafepay.com\');"><img src="view/image/payment/multisafepay.png" alt="MultiSafepay" title="MultiSafepay" style="border: 1px solid #EEEEEE;" /></a>';
?>