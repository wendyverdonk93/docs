<?php

// Heading
$_['heading_title'] = 'Toeslag voor achteraf betalen';

// Text
$_['text_total'] = 'Order Totaal';
$_['text_success'] = 'Wijzigen van de toeslag is geslaagd.!';
$_['text_edit'] = 'Wijzig de toeslag voor achteraf betalen';


// Entry
$_['entry_total'] = 'Order Totaal';
$_['entry_fee'] = 'Toeslag Factuur';
$_['entry_tax_class'] = 'BTW Groep';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sorteervolgorde';
$_['text_netherlands'] = 'Nederland';

// Error
$_['error_permission'] = 'Waarschuwing: U heeft geen rechten om de instellingen te wijzigen!';