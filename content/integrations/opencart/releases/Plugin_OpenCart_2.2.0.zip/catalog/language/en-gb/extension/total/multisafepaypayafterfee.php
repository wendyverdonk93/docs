<?php

$_['text_payafter_fee'] = 'Payment Fee';
