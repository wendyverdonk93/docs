<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_973b8b150e948417a276d253877d19cb'] = 'Direct Bank Transfer';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_d670196c5f2dd031b084d0a2cc0e6c02'] = 'Accepteer DotPay betalingen via MultiSafepay';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_de62775a71fc2bf7a13d7530ae24a7ed'] = 'lgemene instellingen';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_6105cb075e7f0a5431dbf81d2bbeffef'] = 'Minimaal orderbedrag voor Direct Bank Transfer';
$_MODULE['<{multisafepaydirectbanktransfer}default-bootstrap>multisafepaydirectbanktransfer_0923923213f6d2ba264902b7a146c556'] = 'Maximaal orderbedrag voor Direct Bank Transfer';
