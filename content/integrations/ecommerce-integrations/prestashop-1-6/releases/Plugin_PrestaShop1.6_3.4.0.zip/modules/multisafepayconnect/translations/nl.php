<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_530d5fccfb19909f14ac66beb90bb0ae'] = 'MultiSafepay Connect';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_d670196c5f2dd031b084d0a2cc0e6c02'] = 'Accepteer betalingen via MultiSafepay';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_2563dc3cf4307f1ef968b04438d1702a'] = 'Minimaal orderbedrag';
$_MODULE['<{multisafepayconnect}default-bootstrap>multisafepayconnect_abcac9aebb2505b3cf76c42e1bfbe8f7'] = 'Maximaal orderbedrag';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_ff69caa9c517aca3c35e3ea1441e5314'] = 'MultiSafepay';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_0ca4b7591a0f2f8206d7e4b22e357f8c'] = 'U heeft gekozen af te rekenen middels MultiSafepay';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayconnect}default-bootstrap>validation_connect_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';