<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_3c0c7a25085b4d9aa4766fca8570208d'] = 'MultiSafepay Paysafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_73c7ff34dcaf5b23d56b2f8eee3ad9dd'] = 'Accepteer Paysafecard betalingen via MultiSafepay';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_2a1424dfc96d2dfa34de3f34c65421cd'] = 'Minimaal orderbedrag voor PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>multisafepaypaysafecard_f84bc3a520a81dd508fed11de934162b'] = 'Maximaal orderbedrag voor PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_ce82a8f85b8fafbfcd0031eed812f855'] = 'PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_f4ab233e1029fd66c5bbc61fe2ff314a'] = 'U heeft gekozen om af te rekenen middels PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>validation_paysafecard_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>payment_ce82a8f85b8fafbfcd0031eed812f855'] = 'PaySafecard';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaypaysafecard}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';