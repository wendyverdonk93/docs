<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_0e16ab6961f2c133bfb8ec3c68099320'] = 'MultiSafepay Giropay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_648ebacc17712f54074393e02a5fed2e'] = 'Accepteer Giropay betalingen via MultiSafepay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_5d1cdca86399c2178bbff032065db386'] = 'Minimaal orderbedrag voorGiropay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>multisafepaygiropay_edc7faf1f2a9330661048e48d32ce967'] = 'Maximaal orderbedrag voor Giropay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_19490ff0e4aedee9d4557721de35f95e'] = 'Giropay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_6385c90b36ddfaf01e034c4038bd647b'] = 'U heeft gekozen af te rekenen middels Giropay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaygiropay}default-bootstrap>validation_giropay_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaygiropay}default-bootstrap>payment_31911306551723245e7417ae4520fecb'] = 'Giropay';
$_MODULE['<{multisafepaygiropay}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaygiropay}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';