<?php

class MultisafepayTokenmanagerModuleFrontController extends ModuleFrontController{

	public function postProcess(){
	
		$id_token = Tools::getValue('id_token');
		$msp_action = Tools::getValue('action');
		
		if(isset($msp_action) && $msp_action == 'del'){
			/* DELETE TOKEN */		
			if($this->context->customer->isLogged()){ // this is for security access
				$id_cust = $this->context->customer->id;
				if(isset($id_cust) && isset($id_token)){
					$result = Db::getInstance()->Execute('DELETE FROM '. _DB_PREFIX_ .Configuration::get('MULTISAFEPAY_TOKENIZATION_TABLE_NAME').' WHERE `id_token` = '. $id_token .' AND `id_customer` = '.$id_cust);
					if($result){
						echo Tools::jsonEncode( array(
		            		'success' => true
		            		//'data' => Db::getInstance()->ExecuteS( 'SELECT * FROM '. _DB_PREFIX_ .Configuration::get('MULTISAFEPAY_TOKENIZATION_TABLE_NAME').' WHERE `id_token` = '. $id_token .' AND `id_customer` = '.$id_cust ),
		            	));
						exit(); // exit here or other message will be send
					}
				}
			}
		}
		
		/* ERROR HANDLING */
		if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
			/* ajax call */	
			echo Tools::jsonEncode( array(
        		'success' => false,
        		'message' => $this->module->l('Invalid Request. Please try later or contact the shop administrator.')
        	));
		}else{
			/* it should never be here - means http normal request from browser */
			echo $this->module->l('Not Authorized. Invalid Request.');	
		}		
		
		exit();
	}
}

