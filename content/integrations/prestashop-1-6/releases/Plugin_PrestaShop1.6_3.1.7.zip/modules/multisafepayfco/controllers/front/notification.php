<?php
/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@multisafepay.com.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

require_once (_PS_MODULE_DIR_.'multisafepay/controllers/front/notification.php');

class MultisafepayFcoNotificationModuleFrontController extends MultisafepayNotificationModuleFrontController
{

    public function postProcess()
    {

        $msp = new Client();

        $this->api  = Configuration::get('MULTISAFEPAY_FCO_API_KEY');
        $this->mode = Configuration::get('MULTISAFEPAY_FCO_SANDBOX');

        if (isset ($this->api)) {
            // Use API/ mode from the specific gateway configuration
            $api = $this->api;
            $mode = $this->mode;
        } else {
            // Use API/ mode from the default configuration
            $api  = Configuration::get('MULTISAFEPAY_API_KEY');
            $mode = Configuration::get('MULTISAFEPAY_SANDBOX');
        }
        $msp->setApiKey($api);
        $msp->setApiUrl($mode);

        $this->transactie = $this->getTransactionStatus($msp);

        $this->updateOrder();

        parent::postProcess();
    }


    private function getTransactionStatus($msp)
    {
        if ( Tools::getValue('api_key') ){

            $this->Debug($_GET, "<br/><br/>Parameters<br/>-----------------------<br/>");
            $this->Debug($_GET, $_GET);

            $results = $this->feeds ($_GET);

            // Reindex array
            $results = $this->reOrderArray($results);

            // create JSON
            $json = json_encode($results);
            $this->Debug($_GET, "<br/><br/>JSON<br/>-----------------------<br/>");
            $this->Debug($_GET, $this->prettyPrint($json));

            die(PHP_EOL . '------------------------------'. PHP_EOL . 'Ready with the feed');
            return ($json);
        }

        $order_id = Tools::getValue('transactionid');
        try {
            $transactie = $msp->orders->get($order_id, $type = 'orders', $body = array(), $query_string = false);
        } catch (Exception $e) {

            $msg = "Unable to get transaction. Error: " . htmlspecialchars($e->getMessage());
            echo $msg;

            $Debug = new Debug($msg);
        }

        return ($transactie);
    }


    private function updateOrder()
    {

        $initial       = (!empty($_REQUEST['type']) ? $_REQUEST['type'] : '');
        $order_id      = Tools::getValue('transactionid');
        $order_id      = strstr($order_id, '-', true);

        $statussen = array ( 'new_order'         => Configuration::get('MULTISAFEPAY_OS_NEW_ORDER'),
                             'initialized'       => Configuration::get('MULTISAFEPAY_OS_INITIALIZED'),
                             'completed'         => Configuration::get('MULTISAFEPAY_OS_COMPLETED'),
                             'uncleared'         => Configuration::get('MULTISAFEPAY_OS_UNCLEARED'),
                             'cancelled'         => Configuration::get('MULTISAFEPAY_OS_CANCELLED'),
                             'void'              => Configuration::get('MULTISAFEPAY_OS_VOID'),
                             'declined'          => Configuration::get('MULTISAFEPAY_OS_DECLINED'),
                             'refunded'          => Configuration::get('MULTISAFEPAY_OS_REFUNDED'),
                             'partial_refunded'  => Configuration::get('MULTISAFEPAY_OS_PARTIAL_REFUNDED'),
                             'expired'           => Configuration::get('MULTISAFEPAY_OS_EXPIRED'),
                             'shipped'           => Configuration::get('MULTISAFEPAY_OS_SHIPPED')
                            );

        $extra_data          = Tools::jsonDecode($this->transactie->var1);
        $cart_id             = $extra_data->id_cart;
        $module_id           = $extra_data->id_module;
        $id_lang             = $extra_data->id_lang;
        $secure_key          = $this->transactie->var2;
        $paid                = $this->transactie->amount / 100;
        $status              = $this->transactie->status;
        $payment_description = 'MultiSafepay '. $this->transactie->payment_details->type;

        // Shipping...
        // ===========
        $carrier_id = null;

        $shipping_method = $this->transactie->order_adjustment->shipping->flat_rate_shipping->name;
        $sql = 'SELECT id_carrier FROM '._DB_PREFIX_.'carrier WHERE name=\''.$shipping_method.'\' and active = 1 and deleted = 0';
        if ($carriers = Db::getInstance()->ExecuteS($sql)) {
            $carrier = array_shift($carriers);
            $carrier_id = $carrier['id_carrier'];
        }

        $customer = null;
        if ($secure_key != 0) {
            $customer = new Customer($secure_key);
        } else {
            $sql = 'SELECT * FROM '._DB_PREFIX_.'customer WHERE active = 1 AND email=\'' . $this->transactie->customer->email . '\'';
            if ($customers = Db::getInstance()->ExecuteS($sql)) {
                $data = array_shift($customers);
                $customer = new Customer($data['id_customer']);
                $secure_key = $customer->secure_key;
            } else {
                $customer = new Customer();
                $customer->email        = $this->transactie->customer->email;
                $customer->lastname     = trim(htmlspecialchars($this->transactie->customer->last_name));
                $customer->firstname    = trim(htmlspecialchars($this->transactie->customer->first_name));
                $cleanpass              = Tools::passwdGen();
                $customer->passwd       = Tools::encrypt($cleanpass);
                $customer->add();
                $secure_key = $customer->secure_key;
                Mail::Send((int)$id_lang, 'account', 'Welcome!', array(
                    '{firstname}'   => $customer->firstname,
                    '{lastname}'    => $customer->lastname,
                    '{email}'       => $customer->email,
                    '{passwd}'      => $cleanpass
                ), $customer->email, $customer->firstname.' '.$customer->lastname);
            }
        }

        $id_billing_address  = null;
        $id_shipping_address = null;
        $addresses = $customer->getAddresses($id_lang);

        foreach ($addresses as $address) {

            if ($address['alias'] == 'Multisafepay Billing' &&
                $address['id_country'] 	== Country::getByIso($this->transactie->customer->country) &&
                $address['lastname'] 	== trim(htmlspecialchars($this->transactie->customer->last_name)) &&
                $address['firstname'] 	== trim(htmlspecialchars($this->transactie->customer->first_name)) &&
                $address['address1'] 	== trim(htmlspecialchars($this->transactie->customer->address1)).' '.trim(htmlspecialchars($this->transactie->customer->house_number)) &&
                $address['city'] 	== trim(htmlspecialchars($this->transactie->customer->city)) &&
                $address['postcode'] 	== trim(htmlspecialchars($this->transactie->customer->zip_code)) &&
                $address['active'] 	== 1 &&
                $address['deleted'] 	== 0) {

                $id_billing_address = $address['id_address'];
            }

            if ($address['alias'] 	== 'Multisafepay Shipping' &&
                $address['id_country'] 	== Country::getByIso($this->transactie->delivery->country) &&
                $address['lastname'] 	== trim(htmlspecialchars($this->transactie->delivery->last_name)) &&
                $address['firstname'] 	== trim(htmlspecialchars($this->transactie->delivery->first_name)) &&
                $address['address1'] 	== trim(htmlspecialchars($this->transactie->delivery->address1)).' '.trim(htmlspecialchars($this->transactie->delivery->house_number)) &&
                $address['city'] 	== trim(htmlspecialchars($this->transactie->delivery->city)) &&
                $address['postcode'] 	== trim(htmlspecialchars($this->transactie->delivery->zip_code)) &&
                $address['active'] 	== 1 &&
                $address['deleted'] 	== 0) {

                $id_shipping_address = $address['id_address'];
            }
        }

        if (!$id_billing_address) {
            $address = new Address();

            $address->alias         = 'Multisafepay Billing';
            $address->id_country    = Country::getByIso($this->transactie->customer->country);
            $address->lastname      = trim(htmlspecialchars($this->transactie->customer->last_name));
            $address->firstname     = trim(htmlspecialchars($this->transactie->customer->first_name));
            $address->address1      = trim(htmlspecialchars($this->transactie->customer->address1)).' '.trim(htmlspecialchars($this->transactie->customer->house_number));
            $address->city          = trim(htmlspecialchars($this->transactie->customer->city));
            $address->postcode      = $this->transactie->customer->zip_code;
            $address->id_customer   = $customer->id;
            $address->add();
            $id_billing_address 	= $address->id;
        }

        if (!$id_shipping_address) {
            $address = new Address();

            $address->alias         = 'Multisafepay Shipping';
            $address->id_country    = Country::getByIso($this->transactie->delivery->country);
            $address->lastname      = trim(htmlspecialchars($this->transactie->delivery->last_name));
            $address->firstname     = trim(htmlspecialchars($this->transactie->delivery->first_name));
            $address->address1      = trim(htmlspecialchars($this->transactie->delivery->address1)).' '.trim(htmlspecialchars($this->transactie->delivery->house_number));
            $address->city          = trim(htmlspecialchars($this->transactie->delivery->city));
            $address->postcode      = $this->transactie->delivery->zip_code;
            $address->id_customer   = $customer->id;
            $address->add();
            $id_shipping_address 	= $address->id;
        }

        $cart = new Cart((int)$cart_id);

        $cart->id_customer          = $customer->id;
        $cart->id_guest             = $this->transactie->var3;
        $cart->id_address_invoice   = $id_billing_address;
        $cart->id_address_delivery  = $id_shipping_address;

        $delivery_option_list = $cart->getDeliveryOptionList();

        if (count($delivery_option_list) == 1) {

            $key = $carrier_id.',';
            foreach ($delivery_option_list as $id_address => $options) {
                if (isset($options[$key])) {
                    $cart->id_carrier = $carrier_id;
                    $cart->setDeliveryOption(array( $id_address => $key ));
                }
            }
        }

        $cart->update();

        if (Order::getOrderByCartId($cart_id)) {

            $order = new Order(Order::getOrderByCartId($cart_id));
            if (in_array($order->getCurrentState(), $statussen)) {

                $history = new OrderHistory();
                $history->id_order = (int)$order->id;

                if ( $order->getCurrentState() != $statussen[$status]) {
                    $history->changeIdOrderState((int)$statussen[$status], $order->id);
                    $history->add();
                }
            }
        }else{
            $this->module->validateOrder((int)$cart_id, $statussen[$status], $paid, $payment_description, null, array(), null, false, $secure_key);
        }

        $sql = 'UPDATE '._DB_PREFIX_.'orders SET id_address_delivery = \'' . $id_shipping_address  . '\'' .
                                              ', id_address_invoice  = \'' . $id_billing_address   . '\'' .
                                              ', payment             = \'' . $payment_description  .'\'  WHERE id_cart = \'' . $cart_id . '\'';
        Db::getInstance()->Execute($sql);


        $url = 'index.php?controller=order-confirmation&id_cart='.(int)($cart_id).'&id_module='.(int)($module_id).'&id_order='.$order_id.'&key='.$secure_key;

        switch ($initial) {
            case 'initial':
                $returl = '<a href="'.$url.'" />Return to webshop..</a>';
                die($returl);
                break;
            case 'redirect':
                Tools::redirect($url);
                break;
            default:
                die ('ok');
        }

    }

    private function feeds ($params){

/*  // done
        www.store.com/index.php?api_key=xxxxx&language=en_US&identifier=products&product_id=10
        www.store.com/index.php?api_key=xxxxx&language=en_US&identifier=products&category_id=x
        www.store.com/index.php?api_key=xxxxx&language=en_US&identifier=tax
        www.store.com/index.php?api_key=xxxxx&language=en_US&identifier=categories
        www.store.com/index.php?api_key=xxxxx&language=en_US&identifier=stock&product_id=10
        www.store.nl/index.php?api_key=xxxxx&identifier=stores
        www.store.com/index.php?api_key=xxxxx&language=en_US&identifier=shipping&countrycode=NL
*/


        $msp = new Client();

        // no API-Key provided
        if (!isset ($params['api_key']))
            die('no API-Key provided');

        // Invalid API-Key
        if ($params['api_key'] != Configuration::get('MULTISAFEPAY_API_KEY'))
            die('Invalid API-Key');

        // no Language provided
        if (!isset($params['language']))
            die('no Language provided');

        // no identifier provided
        if (!isset ($params['identifier']))
            die(' no identifier provided');

        if ( $params['identifier'] == 'products'  && isset($params['product_id']) && $params['product_id'] != '')
            return ($this->productById($params));

        if ( $params['identifier'] == 'products'  && isset($params['category_id']) && $params['category_id'] != '' )
            return ($this->productByCategory($params));

        if ( $params['identifier'] == 'tax')
            return ($this->tax($params));

        if ( $params['identifier'] == 'category')
            return ($this->categories($params));

        if ( $params['identifier'] == 'stock'  && isset($params['product_id']) && $params['product_id'] != '' )
            return ($this->stock($params));

        if ( $params['identifier'] == 'stores')
            return ($this->stores($params));

        if ( $params['identifier'] == 'shipping')
            return ($this->shipping($params));

        return (array ('No results available'));
    }

    private function tax ($params, $active_only=true){

        $id_language = $this->getLanguageID($params);

        $sql = " SELECT t1.id_tax, t1.rate, t2.name, GROUP_CONCAT( DISTINCT (t4.iso_code) SEPARATOR ',') AS countries
                   FROM " . _DB_PREFIX_ . "tax      t1
              LEFT JOIN " . _DB_PREFIX_ . "tax_lang t2 ON ( t1.id_tax = t2.id_tax  )
              LEFT JOIN " . _DB_PREFIX_ . "tax_rule t3 ON ( t1.id_tax = t3.id_tax  )
              LEFT JOIN " . _DB_PREFIX_ . "country  t4 ON ( t3.id_country = t4.id_country  )
                  WHERE t1.deleted != 1
                    AND t1.active   = " . $active_only . "
                    AND t2.id_lang  = " . $id_language . "
                  GROUP BY t1.id_tax
                  ORDER BY ( t1.id_tax)";

        $allTaxes = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        foreach ($allTaxes as $tax){
            $taxes[$tax ['id_tax']]['id']   = $tax ['id_tax'];
            $taxes[$tax ['id_tax']]['name'] = $tax ['name'];

            $countries = explode(",", $tax['countries']);
            foreach ($countries as $country){
                $taxes[$tax ['id_tax']]['rules'][]  = array ($country => $tax['rate']);
            }
        }

        return($taxes);
    }

    private function productById ($params){

        $id_language = $this->getLanguageID($params);
        $id_country  = $this->getCountryID($params);
        $id_product  = $params['product_id'];
        $active_only = true;
        $id_category = '';

        $results = $this->product($id_language, $id_country, $id_product, $id_category, $active_only);
        return ($results);
    }

    private function productByCategory ($params){

        $id_language = $this->getLanguageID($params);
        $id_country  = $this->getCountryID($params);
        $id_category = $params['category_id'];
        $active_only = true;
        $id_product  = '';

        $results = $this->product($id_language, $id_country, $id_product, $id_category);
        return ($results);
    }

    private function product ($id_language, $id_country, $id_product=null, $id_category=null, $active_only=true){

// todo: FTIN, MPN, metadata, attributes, options

        global $cookie;
        $currency = new CurrencyCore($cookie->id_currency);
        $currency = $currency->iso_code;

        $sql = 'SELECT
                        p.id_product         AS "ProductID",
                        pl.name              AS "ProductName",
                        ma.name              AS "Brand",
                        p.ean13              AS "SKUnumber",
                        ca.name              AS "PrimaryCategory",
                        ""                   AS "SecondaryCategory",
                        ""                   AS "ProductURL",
                        pl.description_short AS "ShortProductDescription",
                        pl.description       AS "LongProductDescription",
                        p.price              AS "SalePrice",
                        p.wholesale_price    AS "RetailPrice",
                        ""                   AS "FTIN",
                        ""                   AS "MPN",
                        ""                   AS "UniqueIdentifier",
                        "'. $currency .'"    AS "Currency",
                        tr.id_tax            AS "TaxId",
                        pq.quantity          AS "Stock",
                        ""                   AS "Metadata",
                        p.date_add           AS "Created",
                        p.date_upd           AS "Updated",
                        p.is_virtual         AS "Downloadable",
                        CONCAT( ROUND(p.width,2), "x", ROUND(p.height,2), "x", ROUND(p.depth,2)) AS "PackageDimensions",
                        p.weight             AS "Weight",
                        ""                   AS "ProductImageURLs",
                        ""                   AS "Attributes",
                        ""                   AS "Options",
                        GROUP_CONCAT(DISTINCT agl.name, ":" ,al.name ORDER BY agl.id_attribute_group SEPARATOR ",") AS attribute_designation

                     FROM ' . _DB_PREFIX_ . 'product                        p
                LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute              pa  ON ( p.id_product               = pa.id_product )
                LEFT JOIN ' . _DB_PREFIX_ . 'stock_available                pq  ON ( p.id_product               = pq.id_product AND pa.id_product_attribute = pq.id_product_attribute )
                LEFT JOIN ' . _DB_PREFIX_ . 'product_lang                   pl  ON ( p.id_product               = pl.id_product )
                LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_combination  pac ON ( pa.id_product_attribute    = pac.id_product_attribute )
                LEFT JOIN ' . _DB_PREFIX_ . 'attribute_lang                 al  ON ( al.id_attribute            = pac.id_attribute)
                LEFT JOIN ' . _DB_PREFIX_ . 'attribute_lang                 pal ON ( pac.id_attribute           = pal.id_attribute )
                LEFT JOIN ' . _DB_PREFIX_ . 'attribute                      a   ON ( a.id_attribute             = pal.id_attribute)
                LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group_lang           agl ON ( agl.id_attribute_group     = a.id_attribute_group)
                LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_image        pai ON ( pa.id_product_attribute    = pai.id_product_attribute )
                LEFT JOIN ' . _DB_PREFIX_ . 'manufacturer                   ma  ON ( p.id_manufacturer          = ma.id_manufacturer )
                LEFT JOIN ' . _DB_PREFIX_ . 'category_lang                  ca  ON ( p.id_category_default      = ca.id_category )
                LEFT JOIN ' . _DB_PREFIX_ . 'tax_rule                       tr  ON ( p.id_tax_rules_group       = tr.id_tax_rules_group AND tr.id_country = ' . $id_country . ')

                WHERE pl.id_lang    = '. $id_language . '
                  AND pal.id_lang   = '. $id_language;
                  ;

        if (!empty ($active_only) && $active_only == true)
            $sql .= ' AND p.active      = '. $active_only;

        if (!empty ($id_product))
            $sql .= ' AND p.id_product  = '. $id_product;

        if (!empty ($id_category))
            $sql .= ' AND p.id_category_default  = '. $id_category;

        $sql .= ' GROUP BY pac.id_product_attribute';


        // Execute SQL statement
        $products = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $tmp_id_product = 0;
        $product = array();
        foreach ($products as $tmp_product){

            // get Product url
            $Product = new Product($tmp_product['ProductID']);
            $link = new Link();
            $tmp_product['ProductURL'] = $link->getProductLink($Product);

            // Get (main) image
            $image = Product::getCover($tmp_product['ProductID']);
            $tmp_product['ProductImageURLs'] = $image ? 'http://'.$link->getImageLink($data['link_rewrite'], $image['id_image'], 'medium_default') : false;




            // Do some aditional layout work.....
            $tmp_product['ShortProductDescription'] = strip_tags ($tmp_product['ShortProductDescription']);
            $tmp_product['LongProductDescription']  = strip_tags ($tmp_product['LongProductDescription']);

            if ($tmp_product['ProductID'] <> $tmp_id_product) {
                $product[$tmp_product['ProductID']] = $tmp_product;
                $tmp_id_product = $tmp_product['ProductID'];
            }

            $product[$tmp_product['ProductID']]['combinaties'][] = $tmp_product['attribute_designation'];
        }

        return( $product);
    }

    private function categories ($params, $active_only=true){

        $id_language = $this->getLanguageID($params);

        $Categories = Category::getNestedCategories($root_category  = null,
                                                    $id_lang        = $id_language,
                                                    $active         = $active_only,
                                                    $group          = null);

        // Remove unwanted values
		$this->recursive_unset($Categories, array ( 'id_parent',
                                                    'id_shop_default',
                                                    'level_depth',
                                                    'nleft',
                                                    'nright',
                                                    'active',
                                                    'date_add',
                                                    'date_upd',
                                                    'position',
                                                    'is_root_category',
                                                    'id_shop',
                                                    'id_lang',
                                                    'description',
                                                    'link_rewrite',
                                                    'meta_title',
                                                    'meta_keywords',
                                                    'meta_description'));

        return ($Categories);
    }

    private function stock ($params){
        $id_product  = $params['product_id'];

        $qty = Product::getQuantity($id_product);

        $stock = array (array ( 'ProductID' => $id_product,
                                'Stock'     => $qty));
        return ($stock);
    }

    private function shipping ($params){

        $id_language = $this->getLanguageID($params);

        $carriers = Carrier::getCarriers($id_language, $active_only=true);

		$this->recursive_unset($carriers, array (   "id_reference",
                                                    "id_tax_rules_group",
                                                    "url",
                                                    "active",
                                                    "deleted",
                                                    "shipping_handling",
                                                    "range_behavior",
                                                    "is_module",
                                                    "is_free",
                                                    "shipping_external",
                                                    "need_range",
                                                    "external_module_name",
                                                    "shipping_method",
                                                    "position",
                                                    "max_width",
                                                    "max_height",
                                                    "max_depth",
                                                    "max_weight",
                                                    "grade",
                                                    "delay"));

        return ($carriers);
    }

    private function stores ($params, $id_shop=1){


        // todo:

        // So I can use the parse_address function.
        $msp = new Client();

        $id_language = $this->getLanguageID($params);

        $sql = " SELECT *
                   FROM " . _DB_PREFIX_ . "shop     s1
              LEFT JOIN " . _DB_PREFIX_ . "store    s2 ON (s1.id_shop = s2.id_store)
                  WHERE s1.deleted != 1
                     AND s1.id_shop = " . $id_shop;

        if (!empty ($active_only) && $active_only == true)
            $sql .= ' AND s1.active = '. $active_only;

        // Execute SQL statement
        $store = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $store = array_shift ($store);

        $shop["name"]               = $store["name"];

        $shop["allowed_countries"]  = $this->getCountries($id_language);
        $shop["languages"]          = array ( $params["language"], array ("title"       =>"title",
                                                              "keywords"    => array ("??", "??"),
                                                              "description" => "??",
                                                              "usps"        => array ( "shipping"   => array (  "??",
                                                                                                                "??",
                                                                                                                "??"),
                                                                                       "global"     => array (  "??",
                                                                                                                "??")
                                                                                      )
                                                              )
                                            );
        $shop["stock_updates"]       = Configuration::get('PS_STOCK_MANAGEMENT') ? 'true' : 'false';
        $shop["including_tax"]       = $this->getInclExclTax();
        $shop["require_shipping"]    = "";
        $shop["base_url"]            = $this->getShopURL();
        $shop["order_push_url"]      = "";
        $shop["coc"]                 = "";
        $shop["email"]               = $store["email"];
        $shop["contact_phone"]       = $store["phone"];

        list ($shop["address"], $shop["housenumber"]) = $msp->parseCustomerAddress($store["address1"]);

        $shop["zipcode"]             = $store["postcode"];
        $shop["city"]                = $store["city"];
        $shop["country"]             = $this->getCountryID($store["id_country"]);

        $shop["vat_nr"]              = "";
        $shop["terms_and_conditions"]= $this->getConditions($params);
        $shop["faq"]                 = "";
        $shop["open"]                = "08:00";
        $shop["closed"]              = "23:00";
        $shop["days"]                = array (  "sunday"      => false,
                                                "monday"      => true,
                                                "tuesday"     => true,
                                                "wednesday"   => true,
                                                "thursday"    => true,
                                                "friday"      => true,
                                                "saturday"    => true );
        $shop["social"]              = array (  "facebook"    => "",
                                                "twitter"     => "",
                                                "linkedin"    => "" );
        return ($shop);
    }




    private function getLanguageID ($params){

        $language = $params['language'];
        $language = strtolower ($params['language']);
        $language = preg_replace('(_)', '-', $language);

        $sql = " SELECT id_lang as 'lang'
                   FROM " . _DB_PREFIX_ . "lang
                  WHERE language_code = " . "'". $language . "'";

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $lang = '';
        if (!empty($result)) {
            $lang = $result[0]['lang'];
        }

        // If no results use the default value 1
        $lang = $lang ? $lang : 1;


        return ($lang);
    }

    private function getCountryID ($params){

        // $params['language'] = 'nl_NL' or 'NL'
        if (strlen ($params['language']) != 2 )
            $country = strtoupper (substr ($params['language'], 0, 2));
        else
            $country = strtoupper ($params['language']);

        $sql = " SELECT id_country as 'id_country'
                   FROM " . _DB_PREFIX_ . "country
                  WHERE iso_code = " . "'". $country . "'";

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        $id_country = 0;
        if (!empty($result)) {
            $id_country = $result[0]['id_country'];
        }

        // If no results use the default value 0
        $id_country = $id_country ? $id_country : 0;


        return ($id_country);
    }



    private function getConditions($params){
        $id_language = $this->getLanguageID($params);

        $cms = new CMS(Configuration::get('PS_CONDITIONS_CMS_ID'), $id_language);
        $link_conditions = $this->context->link->getCMSLink($cms, $cms->link_rewrite, Configuration::get('PS_SSL_ENABLED'));
        if (!strpos($link_conditions, '?')) {
            $link_conditions .= '?content_only=1';
        } else {
            $link_conditions .= '&content_only=1';
        }
        return ($link_conditions);

     }

    private function getCountries($id_language = 1, $active = true, $contain_states = false, $list_states = false){

        $countries = Country::getCountries($id_language, true);
        foreach ($countries as $country){
            $iso_codes[] = $country['iso_code'];
        }
        return ($iso_codes);
     }

    private function getShopURL($id_shop=1){

        $sql = "SELECT physical_uri AS 'url'
                   FROM " . _DB_PREFIX_ . "shop_url
                  WHERE id_shop =".  $id_shop;

        // Execute SQL statement
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        $result = array_shift ($result);

        return ($result['url']);
     }




    private function getInclExclTax(){

        // Prices incl or excl. tax can be different for each customer group.
        // I will check if the most groups uses incl. or excl. Tax.

        $sql = "SELECT CASE WHEN price_display_method = 0 THEN 'incl' ELSE 'excl' END AS method, count(price_display_method) AS occurrence
                   FROM " . _DB_PREFIX_ . "group
                  GROUP BY (price_display_method)";

        // Execute SQL statement
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
        foreach ($result as $row){
            $method[$row['method']] = $row['occurrence'];
        }
        // All groups are excl.
        if (!isset ($method['incl']))
            return ('false');

        // All groups are incl.
        if (!isset ($method['excl']))
            return ('true');

        if ($method['incl'] >= $method['excl'] )
            return ('true');
        else
            return ('false');
     }

    private function Debug ($params, $msg){

        if ( isset($params['debug']) && $params['debug'] != '' ) {
            if(is_array($msg)) {
                echo '<pre>';
                print_r ($msg);
            }else{
                echo $msg;
            }
        }
    }

	private function recursive_unset(&$array, $unsets) {

        foreach ($unsets as $unset){
            unset ($array[$unset]);
        }
		foreach ($array as &$value) {
			if (is_array($value)) {
				$this->recursive_unset($value, $unsets);
			}
		}
	}

    private function reOrderArray($array) {
        if(!is_array($array)) {
             return $array;
        }
        $count = 0;
        $result = array();
        foreach($array as $k => $v) {
            if($this->is_integer_value($k)) {
               $result[$count] = $this->reOrderArray($v);
               ++$count;
            } else {
              $result[$k] = $this->reOrderArray($v);
            }
        }
        return $result;
    }

    private function is_integer_value($value) {
        if(!is_int($value)) {
            if(is_string($value) && preg_match("/^-?\d+$/i",$value)) {
                return true;
            }
            return false;
        }
        return true;
    }

    private function prettyPrint( $json )  {
        $result = '';
        $level = 0;
        $in_quotes = false;
        $in_escape = false;
        $ends_line_level = NULL;
        $json_length = strlen( $json );

        for( $i = 0; $i < $json_length; $i++ ) {
            $char = $json[$i];
            $new_line_level = NULL;
            $post = "";
            if( $ends_line_level !== NULL ) {
                $new_line_level = $ends_line_level;
                $ends_line_level = NULL;
            }
            if ( $in_escape ) {
                $in_escape = false;
            } else if( $char === '"' ) {
                $in_quotes = !$in_quotes;
            } else if( ! $in_quotes ) {
                switch( $char ) {
                    case '}': case ']':
                        $level--;
                        $ends_line_level = NULL;
                        $new_line_level = $level;
                        break;

                    case '{': case '[':
                        $level++;
                    case ',':
                        $ends_line_level = $level;
                        break;

                    case ':':
                        $post = " ";
                        break;

                    case " ": case "\t": case "\n": case "\r":
                        $char = "";
                        $ends_line_level = $new_line_level;
                        $new_line_level = NULL;
                        break;
                }
            } else if ( $char === '\\' ) {
                $in_escape = true;
            }
            if( $new_line_level !== NULL ) {
                $result .= "\n".str_repeat( "\t", $new_line_level );
            }
            $result .= $char.$post;
        }

        return $result;
    }
}
