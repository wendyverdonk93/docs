<?php
/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@multisafepay.com.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */


class MultisafepayNotificationModuleFrontController extends ModuleFrontController
{
    public $order_id;
    public $states;
    public $statussen;
    public $cart_id;
    public $secure_key;
    public $paid;
    public $initial;
    public $transactie;
    public $status;

    public function initContent()
    {

        $transactionid = Tools::getValue('transactionid');
        $this->lock_file = 'trns_' . $transactionid . '.lck';

        if ( Tools::getValue('timestamp') ){
            $tries = 1;
            while ( $tries < 10) {

                if (file_exists($this->lock_file)) {
                    sleep (1);
                    $tries++;
                }else{
                    fopen($this->lock_file, "w");
                    $tries = 99;
                }
            }

            if ($tries == 10){

                // When still locked after 10 seconds something was wrong.
                // unlock this file...
                $this->unlock();
                die ('ng');
            }

            $this->statussen = array ( 'new_order'         => Configuration::get('MULTISAFEPAY_OS_NEW_ORDER'),
                                       'initialized'       => Configuration::get('MULTISAFEPAY_OS_INITIALIZED'),
                                       'completed'         => Configuration::get('MULTISAFEPAY_OS_COMPLETED'),
                                       'uncleared'         => Configuration::get('MULTISAFEPAY_OS_UNCLEARED'),
                                       'cancelled'         => Configuration::get('MULTISAFEPAY_OS_CANCELLED'),
                                       'void'              => Configuration::get('MULTISAFEPAY_OS_VOID'),
                                       'declined'          => Configuration::get('MULTISAFEPAY_OS_DECLINED'),
                                       'refunded'          => Configuration::get('MULTISAFEPAY_OS_REFUNDED'),
                                       'partial_refunded'  => Configuration::get('MULTISAFEPAY_OS_PARTIAL_REFUNDED'),
                                       'expired'           => Configuration::get('MULTISAFEPAY_OS_EXPIRED'),
                                       'shipped'           => Configuration::get('MULTISAFEPAY_OS_SHIPPED')
                                     );

            $msp = new Client();

            if (isset ($this->api)) {
                // Use API/ mode from the specific gateway configuration
                $api = $this->api;
                $mode = $this->mode;
            } else {
                // Use API/ mode from the default configuration
                $api  = Configuration::get('MULTISAFEPAY_API_KEY');
                $mode = Configuration::get('MULTISAFEPAY_SANDBOX');
            }
            $msp->setApiKey($api);
            $msp->setApiUrl($mode);

            try {
                $this->transactie = $msp->orders->get($transactionid, 'orders', array(), false);
            } catch (Exception $e) {

                $msg = "Unable. to get transaction. Error: " . htmlspecialchars($e->getMessage());
                $Debug = new Debug($msg);
            }

            // Test if transaction exist
            if ($this->transactie->order_id){
                $extra_data          = Tools::jsonDecode($this->transactie->var1);
                $cart_id             = $extra_data->id_cart;

                $this->cart_id          = $cart_id;
                $this->secure_key       = $this->transactie->var2;
                $this->paid             = $this->transactie->amount /100;
                $this->order_id         = $this->transactie->order_id;
                $this->status           = $this->transactie->status;
                $this->transaction_id   = $this->transactie->transaction_id;

                // If timestamp or type=redirect, process, otherwise not
                if (Tools::getValue('timestamp') || Tools::getValue('type') == 'redirect') {

                    switch (Configuration::get('MULTISAFEPAY_WHEN_CREATE_ORDER'))
                    {
                      case 'After_Confirmation':
                          $this->afterConfirmation();
                          break;

                      case 'After_Payment_Complete':
                          $this->afterPaymentComplete();
                          break;

                      case 'After_Payment_Complete_Inc_Banktrans':
                          $this->afterPaymentCompleteIncBanktrans();
                          break;
                    }
                }
            }
        }


        $this->unlock();
        $url = 'index.php?controller=order-confirmation&id_cart='.(int)($this->cart_id).'&id_module='.(int)($this->module->id).'&id_order='.$this->order_id.'&key='.$this->secure_key;

        switch ( Tools::getValue('type') ) {
            case 'initial':
                die();
            case 'redirect':
                Tools::redirect($url);
                break;

            case 'cancel':
	            $msp = new Client();
	            if (isset ($this->api)) {
	                // Use API/ mode from the specific gateway configuration
	                $api = $this->api;
	                $mode = $this->mode;
	            } else {
	                // Use API/ mode from the default configuration
	                $api  = Configuration::get('MULTISAFEPAY_API_KEY');
	                $mode = Configuration::get('MULTISAFEPAY_SANDBOX');
	            }
	            $msp->setApiKey($api);
	            $msp->setApiUrl($mode);

	            try {
	                $this->transactie = $msp->orders->get($transactionid, 'orders', array(), false);
	            } catch (Exception $e) {

	                $msg = "Unable to get transaction. Error: " . htmlspecialchars($e->getMessage());
	                $Debug = new Debug($msg);
	            }

                $context = Context::getContext();
				$products = count ($context->cart->getproducts());

				if ($products == 0 ) {
					// Test if transaction exist
					if (isset ($this->transactie->order_id) ){

						$extra_data          = Tools::jsonDecode($this->transactie->var1);
						$this->cart_id       = $extra_data->id_cart;

						//load order again to create a new cart based on the previous order
						$order = new Order(Order::getOrderByCartId((int)$this->cart_id));

						if (!$context->cart->id) {
							$context->cart->add();
							$context->cookie->id_cart = $context->cart->id;
						}

						foreach ($order->getProducts() as $key => $product_data){
							$context->cart->updateQty(  $product_data['product_quantity'],
														$product_data['product_id'],
														$product_data['product_attribute_id']);
						}
					}else{

						$query = 'SELECT id_cart FROM ' . _DB_PREFIX_. 'cart WHERE id_customer = '. $context->cart->id_customer . ' ORDER BY id_cart desc';
						$id_cart = Db::getInstance()->getValue($query);

						$query = 'SELECT id_order FROM '._DB_PREFIX_. 'orders WHERE id_cart = '. $id_cart;
						$id_order = Db::getInstance()->getValue($query);

						$query = 'SELECT id_cart, id_product, id_product_attribute, quantity FROM '._DB_PREFIX_. 'cart_product WHERE id_cart = ' . $id_cart;
						$results = Db::getInstance()->executeS($query);

						//load order again to create a new cart based on the previous order
						$order = new Order($id_order);

						if (!$context->cart->id) {
						  $context->cart->add();
						  $context->cookie->id_cart = $context->cart->id;
						}

						foreach ($results as $product_data){

							$context->cart->updateQty($product_data['quantity'],
													  $product_data['id_product'],
													  $product_data['id_product_attribute']);

						}

					}
				}
                $url = "index.php?controller=order&step=3";

                Tools::redirect($url);
                exit;

            default:
                die ('ok');
        }
    }


    private function unlock()
    {
        if (file_exists($this->lock_file))
            unlink ($this->lock_file);
    }

    private function afterConfirmation()
    {
        $this->updateOrder();
    }

    private function afterCheckoutComplete()
    {
        $this->updateOrCreateOrder();
    }

    private function afterPaymentComplete()
    {
        if ( $this->status == 'completed') {
            $this->updateOrCreateOrder();
        }
        if ($this->transactie->payment_details->type == 'BANKTRANS'){
           $this->context->cart->delete();
        }

    }

    private function afterPaymentCompleteIncBanktrans()
    {
        if ($this->status == 'completed' || $this->transactie->payment_details->type == 'BANKTRANS') {
            $this->updateOrCreateOrder();
        }

        if ($this->transactie->payment_details->type == 'BANKTRANS'){
            $this->context->cart->delete();
        }
    }

    private function updateOrCreateOrder()
    {
        if ($this->cart_id && Order::getOrderByCartId((int)$this->cart_id)){
            $this->updateOrder();
        }else{
            $this->createOrder();
        }
    }

    private function updateOrder()
    {
        // Order should already exists
        $order = new Order(Order::getOrderByCartId((int)$this->cart_id));

        $history = new OrderHistory();
        $history->id_order = (int)$order->id;

        // If current order-state is not a MultiSafepay order-state, then do not update the status anymore.
        if ( !array_search($order->getCurrentState(), $this->statussen)){
            return;
        }

        if ($order->getCurrentState() != $this->statussen[$this->status]) {

            $history->changeIdOrderState((int)$this->statussen[$this->status], $order->id);
            $history->add();
        }

        if ($this->status == 'completed') {
            $payments = $order->getOrderPaymentCollection();
            $payments[0]->transaction_id = $this->transaction_id;
            $payments[0]->update();
        }


    }

    private function createOrder()
    {
        $msg = 'MultiSafepay reference: '       . $this->order_id;
        $this->module->validateOrder((int)$this->cart_id, $this->statussen[$this->status], $this->paid, $this->module->displayName, $msg, array(), null, false, $this->secure_key);
//        Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)($this->cart_id).'&id_module='.(int)($this->module->id).'&id_order='.$this->order_id.'&key='.$this->secure_key);
    }
}
