<?php
/**
 *  MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@MultiSafepay.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

class PaymentFee
{
    public function getFee($gateway)
    {
        if (Module::isInstalled('bvkpaymentfees')) {
            $fee =Db::getInstance()->getRow('SELECT increment, multiply  FROM `'._DB_PREFIX_.'bvk_paymentfees` WHERE name=\'' . $gateway . '\'');

            if ($fee && !array_key_exists("increment",$fee))
                $fee['increment'] = 0;

            if ($fee && !array_key_exists("multiply",$fee))
                $fee['multiply'] = 0;

            if ($fee['multiply'] > 0)
                $fee['multiply'] = ($fee['multiply'] - 1) * 100;


            return ($fee);
        }
    }
}
?>