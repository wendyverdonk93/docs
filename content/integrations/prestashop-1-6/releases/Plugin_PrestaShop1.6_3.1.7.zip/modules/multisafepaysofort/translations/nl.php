<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_14612d448a063f26ecdfd989361edd1a'] = 'MultiSafepay SOFORT';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_514d6ab4c45cb9432f788befbf635139'] = 'Accepteer SOFORT betalingen via MultiSafepay';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_a7071fc91128210705fc4377aeef9bf4'] = 'Minimaal orderbedrag voor  SOFORT';
$_MODULE['<{multisafepaysofort}default-bootstrap>multisafepaysofort_17392613bd6f4a775685af50d928a89c'] = 'Maximaal orderbedrag voor  SOFORT';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_8ad65eb3da9995173280649f090218c3'] = 'SOFORT';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_f954d5f5e9c251096d6d0641c8f3cfe9'] = 'U heeft gekozen om af te rekenen middels SOFORT';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaysofort}default-bootstrap>validation_directbank_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaysofort}default-bootstrap>payment_8ad65eb3da9995173280649f090218c3'] = 'SOFORT';
$_MODULE['<{multisafepaysofort}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaysofort}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';
