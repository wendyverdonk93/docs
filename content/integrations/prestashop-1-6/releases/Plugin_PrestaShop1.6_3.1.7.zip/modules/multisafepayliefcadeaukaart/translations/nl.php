<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_3a8cd466edaee5bf9061305300b7bb1d'] = 'MultiSafepay Lief Cadeaukaart';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_e273557a2c2ef551c7d4cdfd6db8f981'] = 'Accepteer Lief Cadeaukaart betalingen via MultiSafepay';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_c888438d14855d7d96a2724ee9c306bd'] = 'Instellingen bijgewerkt';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_8af703b2bf59cc9742883ae7f4cb0e5b'] = 'Instellingen account';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_d876ff8da67c3731ae25d8335a4168b4'] = 'API-Sleutel';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_6e147eeb6094904219d0987806735f5c'] = 'De API-Sleutel van de betreffende website in het MultiSafepay account. Indien leeg, dan wordt de API-Sleutel van de Standaard MultiSafepay configuratie gebruikt.';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_b02b464fbe0b40f0c481f17894f66747'] = 'Test account';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_138780f997031206bb8ee5390e36e08a'] = 'Gebruik LIVE-account als de API-Sleutel van een Live-account is. Gebruik TEST-account als de API-Sleutel van een Test-account is.';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>multisafepayliefcadeaukaart_638ce87fab4d636ed19f2517b40a48fd'] = 'Live account';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_34e28375ab0d1c205e3e7bdd90e1f315'] = 'Lief Cadeaukaart';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_a8abbcca999f4898f9c23522745b858d'] = 'U heeft gekozen om af te rekenen middels Lief Cadeaukaart';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>validation_liefcadeaukaart_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepayliefcadeaukaart}default-bootstrap>payment_34e28375ab0d1c205e3e7bdd90e1f315'] = 'Lief Cadeaukaart';