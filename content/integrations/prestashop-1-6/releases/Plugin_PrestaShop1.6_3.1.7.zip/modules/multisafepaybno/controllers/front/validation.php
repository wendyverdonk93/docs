<?php
/**
 * MultiSafepay Payment Module
 *
 *  @author    MultiSafepay <techsupport@multisafepay.com.com>
 *  @copyright Copyright (c) 2013 MultiSafepay (http://www.multisafepay.com)
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */

require_once (_PS_MODULE_DIR_.'multisafepay/controllers/front/validation.php');

class MultisafepayBnoValidationModuleFrontController extends MultisafepayValidationModuleFrontController
{
    public function postProcess()
    {
        $this->api  = Configuration::get('MULTISAFEPAY_BNO_API_KEY');
        $this->mode = Configuration::get('MULTISAFEPAY_BNO_SANDBOX');

        if (Configuration::get('MULTISAFEPAY_BNO_DIRECT')) {
            $this->type = 'direct';
            $this->getGatewayInfo();
        } else {
            $this->type = 'redirect';
            $this->gatewayInfo = '';
        }

        $this->getCart();
        parent::postProcess();
    }

    private function getGatewayInfo()
    {
        if ($this->context->cart->id_customer == 0 || $this->context->cart->id_address_delivery == 0 || $this->context->cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirectLink(__PS_BASE_URI__.'order.php?step=1');
        }

        $customer = new Customer($this->context->cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            Tools::redirectLink(__PS_BASE_URI__.'order.php?step=1');
        }

        if (Tools::getValue('bankaccount') <> '') {
            $this->context->cookie->__set('bankaccount', Tools::getValue('bankaccount'));
        }
        if (Tools::getValue('phone') <> '') {
            $this->context->cookie->__set('phone', Tools::getValue('phone'));
        }
        if (Tools::getValue('birthday') <> '') {
            $this->context->cookie->__set('birthday', Tools::getValue('birthday'));
        }

        $this->gatewayInfo = array(
            'referrer'    => $_SERVER['HTTP_REFERER'],
            'user_agent'  => $_SERVER['HTTP_USER_AGENT'],
            'birthday'    => $this->context->cookie->birthday,
            'bankaccount' => $this->context->cookie->bankaccount,
            'phone'       => $this->context->cookie->phone,
            'email'       => $customer->email,
            'gender'      => ''
        );
    }

    private function getCart()
    {
        $cart = $this->context->cart;
        $total_data = $cart->getSummaryDetails();

        $this->shopping_cart    = array();
        $this->checkout_options = array();
        $this->checkout_options['tax_tables']['default'] = array ( 'shipping_taxed'=> 'true', 'rate' => '0.21');
        $this->checkout_options['tax_tables']['alternate'][] = '';

        // Products
        $products = $cart->getProducts();
        $items = "<ul>\n";

        foreach ($products as $product) {
            //	  $product[ecotax]
            //    $product[additional_shipping_cost]

            $items .= "<li>";
            $items .= $product['cart_quantity'].' x : '.$product['name'];
            if (!empty($product['attributes_small'])) {
                $items .= '('.$product['attributes_small'].')';
            }
            $items .= "</li>\n";

            $this->shopping_cart['items'][] = array (
                'name'  		 		=> $product['name'],
                'description' 		 	=> $product['description_short'],
                'unit_price'  		 	=> round($product['price'], 4),
                'quantity'    		 	=> $product['quantity'],
                'merchant_item_id' 	 	=> $product['id_product'],
                'tax_table_selector'    => $product['tax_name'],
                'weight' 		 		=> array ('unit'=> $product['weight'], 'value'=> 'KG')
            );

            array_push($this->checkout_options['tax_tables']['alternate'], array ('name' => $product['tax_name'], 'rules' => array (array ('rate' => $product['rate']/100 ))));
        }

        // Fee
        $fee  = $this->module->fee;
        $total = $this->context->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS);

        if ($fee['increment'] > 0 ){
            $this->shopping_cart['items'][] = array (
                'name'  		     => 'Fee (fixed)',
                'description' 		 => 'Fee ' . $fee['increment'],
                'unit_price'  		 => $fee['increment'],
                'quantity'    		 => 1,
                'merchant_item_id' 	 => 'Fee',
                'tax_table_selector' => 'Fee',
                'weight' 		     => array ('unit'=> 0, 'value'=> 'KG')
            );
            array_push($this->checkout_options['tax_tables']['alternate'], array ('name' => 'Fee', 'rules' => array (array ('rate' => '0.00'))));
        }

        if ($fee['multiply'] > 0 ){

            $multiply = round (1+ ($fee['multiply']/100), 2);

            $this->shopping_cart['items'][] = array (
                'name'  		     => 'Fee (%)',
                'description' 		 => 'Fee ' . $fee['multiply'] . '%',
                'unit_price'  		 => ($total * $multiply) - $total,
                'quantity'    		 => 1,
                'merchant_item_id' 	 => 'Fee',
                'tax_table_selector' => 'Fee',
                'weight' 		     => array ('unit'=> 0, 'value'=> 'KG')
            );
            array_push($this->checkout_options['tax_tables']['alternate'], array ('name' => 'Fee', 'rules' => array (array ('rate' => '0.00'))));
        }

        // Discount
        if ($total_data['total_discounts'] > 0) {

            $this->shopping_cart['items'][] = array (
                'name'  		 => 'Discount',
                'description' 		 => 'Discount',
                'unit_price'  		 => round(-$total_data['total_discounts'], 4),
                'quantity'    		 => 1,
                'merchant_item_id' 	 => 'Discount',
                'tax_table_selector'     => 'Discount',
                'weight' 		 => array ('unit'=> 0, 'value'=> 'KG')
            );
            array_push($this->checkout_options['tax_tables']['alternate'], array ('name' => 'Discount', 'rules' => array (array ('rate' => '0.00'))));
        }

        // Wrapping
        if ($total_data['total_wrapping'] > 0) {

            $this->shopping_cart['items'][] = array (
                'name'              => 'Wrapping',
                'description' 		=> 'Wrapping',
                'unit_price'  		=> round($total_data['total_wrapping_tax_exc'], 4),
                'quantity'    		=> 1,
                'merchant_item_id' 	=> 'Wrapping',
                'tax_table_selector'=> 'Wrapping',
                'weight'            => array ('unit'=> 0,  'value'=> 'KG')
            );

            if ( $total_data['total_wrapping_tax_exc'] > 0 ){
                $wrapping_tax_percentage = round (($total_data['total_wrapping'] - $total_data['total_wrapping_tax_exc']) * ( $total_data['total_wrapping_tax_exc']), 2);
            }else{
                $wrapping_tax_percentage = 0;
            }
            array_push($this->checkout_options['tax_tables']['alternate'], array ('name' => 'Wrapping', 'rules' => array (array ('rate' => $wrapping_tax_percentage))));
        }

        // Shipping
        $this->shopping_cart['items'][] = array (
            'name'              => 'Shipping',
            'description' 		=> 'Shipping',
            'unit_price'  		=> round($total_data['total_shipping_tax_exc'], 4),
            'quantity'    		=> 1,
            'merchant_item_id' 	=> 'msp-shipping',
            'tax_table_selector'=> 'Shipping',
            'weight'            => array ('unit'=> 0,  'value'=> 'KG')
        );

        if ( $total_data['total_shipping_tax_exc'] > 0 ){
            $shipping_tax_percentage = round (($total_data['total_shipping'] - $total_data['total_shipping_tax_exc']) / ( $total_data['total_shipping_tax_exc']), 2);
        }else{
            $shipping_tax_percentage = 0;
        }
        array_push($this->checkout_options['tax_tables']['alternate'], array ('name' => 'Shipping', 'rules' => array (array ('rate' => $shipping_tax_percentage))));

        $items .= "</ul>\n";
    }
}
