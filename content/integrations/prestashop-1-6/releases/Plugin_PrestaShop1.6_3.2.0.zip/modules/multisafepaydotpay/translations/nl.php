<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_7bb016223b3dc8b949a585b9a46a9932'] = 'MultiSafepay DotPay';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_82e2f1a5eb1538c9ff4fcf3f90866692'] = 'Accepteer DotPay betalingen via MultiSafepay';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_07c6a3757ed1a107277e3a11f5dde030'] = 'Minimaal orderbedrag voor DotPay';
$_MODULE['<{multisafepaydotpay}default-bootstrap>multisafepaydotpay_467857d42a94cc7878522dc58452512e'] = 'Maximaal orderbedrag voor DotPay';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_24d9ce17e002ba134d39a985dc6fff50'] = 'DotPay';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_00654527912f3ac3639322b4e730b7c3'] = 'U heeft gekozen om af te rekenen middels ';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaydotpay}default-bootstrap>validation_dotpay_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaydotpay}default-bootstrap>payment_24d9ce17e002ba134d39a985dc6fff50'] = 'DotPay';
$_MODULE['<{multisafepaydotpay}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaydotpay}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';