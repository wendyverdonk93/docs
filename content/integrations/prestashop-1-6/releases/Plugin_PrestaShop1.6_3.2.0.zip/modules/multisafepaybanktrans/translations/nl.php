<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_e651ea998897a94abf6807e320003459'] = 'MultiSafepay Bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_8b03d89100563d5652ed225a102ab831'] = 'Accepteer Bankoverboekingen via MultiSafepay';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_8ec92321754e6af899c09da9c9fd4e0e'] = 'Direct Bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nee';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_3c2e285225b533597ccab7d3665dc9bf'] = 'Accepteer de aanvullende velden op de afreken pagina of in een nieuw scherm';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_ad8955e847e3013091a230fffec335e7'] = 'Minimaal orderbedrag voor Bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>multisafepaybanktrans_320e5b41f94cbef2b76ac56912f00d89'] = 'Maximaal orderbedrag voor Bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_4a9971e0aefb3bc26e82bfa28130d6ef'] = 'Bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_300e81da4ca798b7057600e5ae7d70f5'] = 'U heeft gekozen af te rekenen middels een bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>validation_banktrans_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>payment_a22ce02ce5af761bd1d3b9ba1beef127'] = 'Bankoverboeking';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaybanktrans}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';