<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_4ec8dfc647a39ba43a8bae924a575d79'] = 'MultiSafepay KBC';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_cc9eb9a9b69e2144ff09da4e4419c818'] = 'Accepteer KBC betalingen via MultiSafepay';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_e09484ba6c16bc20236b63cc0d87ee95'] = 'Weet u zeker dat u uw gegevens wilt verwijderen?';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_630f6dc397fe74e52d5189e2c80f282b'] = 'Terug naar overzicht';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_de62775a71fc2bf7a13d7530ae24a7ed'] = 'Algemene instellingen';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_0fd70afa7076b00fbcadd145c452e3b5'] = 'Minimaal orderbedrag voor KBC';
$_MODULE['<{multisafepaykbc}default-bootstrap>multisafepaykbc_2a0e557f6179e17c97151bd9810bdc2d'] = 'Maximaal orderbedrag voor KBC';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_c453a4b8e8d98e82f35b67f433e3b4da'] = 'Betaling';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_f1d3b424cd68795ecaa552883759aceb'] = 'Samenvatting bestelling';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_ecebb605bd2ee9f4c5d348edbe959fa9'] = 'KBC';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_f6fbb23b0d995d0a84b79794da306757'] = 'Accepteer KBC betalingen via MultiSafepay';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_ed57a2014f48893f7dd212a63d04affa'] = 'Het totale orderbedrag is';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_ed22ee154638b5264b512354ad82a8f5'] = '(Incl. BTW)';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_4a4c2e30df9cc2e90dd4012312ee3745'] = 'Wijzig betaalmethode';
$_MODULE['<{multisafepaykbc}default-bootstrap>validation_kbc_7395559a94fa7a25907a155cda78afa0'] = 'Bevestig order';
$_MODULE['<{multisafepaykbc}default-bootstrap>payment_ecebb605bd2ee9f4c5d348edbe959fa9'] = 'KBC';
$_MODULE['<{multisafepaykbc}default-bootstrap>payment_cdd80725f5dc58cf095a79522f53b783'] = '(+';
$_MODULE['<{multisafepaykbc}default-bootstrap>payment_fe3c3478a12aab63c68b3958adf533e6'] = ')';